import tkinter as tk
from tkinter import ttk, messagebox
import random
import json
import os

# ── colour palette ──────────────────────────────────────────────────────────
COLORS = {
    "bg":        "#1a1a2e",
    "card":      "#16213e",
    "accent1":   "#e94560",
    "accent2":   "#0f3460",
    "accent3":   "#533483",
    "green":     "#00b894",
    "yellow":    "#fdcb6e",
    "orange":    "#e17055",
    "blue":      "#74b9ff",
    "pink":      "#fd79a8",
    "purple":    "#a29bfe",
    "white":     "#ffffff",
    "gray":      "#636e72",
    "light":     "#dfe6e9",
}

SUBJECTS = {
    "🔢 Math":     {"color": "#00b894", "bg": "#00634a", "questions": [
        {"q": "🍎 If you have 5 apples and eat 2, how many are left?",
         "opts": ["1", "2", "3", "4"], "ans": 2, "exp": "5 - 2 = 3 apples! 🍎🍎🍎"},
        {"q": "🐣 3 hens each lay 4 eggs. How many eggs in total?",
         "opts": ["7", "10", "12", "15"], "ans": 2, "exp": "3 × 4 = 12 eggs! 🥚"},
        {"q": "🌟 What is 7 + 8?",
         "opts": ["13", "14", "15", "16"], "ans": 2, "exp": "7 + 8 = 15! Count on your fingers!"},
        {"q": "🍕 A pizza has 8 slices. You eat 3. How many slices remain?",
         "opts": ["3", "4", "5", "6"], "ans": 2, "exp": "8 - 3 = 5 slices left! 🍕🍕🍕🍕🍕"},
        {"q": "🐟 There are 4 ponds with 6 fish each. Total fish?",
         "opts": ["10", "20", "24", "30"], "ans": 2, "exp": "4 × 6 = 24 fish! 🐟"},
    ]},
    "📖 Reading":  {"color": "#74b9ff", "bg": "#1a5276", "questions": [
        {"q": "🔤 Which word rhymes with CAT?",
         "opts": ["Dog", "Hat", "Cup", "Sun"], "ans": 1, "exp": "CAT & HAT both end in -AT! 🎩"},
        {"q": "📚 What is the OPPOSITE of 'hot'?",
         "opts": ["Warm", "Cool", "Cold", "Icy"], "ans": 2, "exp": "Hot ↔ Cold — opposites! 🌡️"},
        {"q": "🔡 How many vowels are in the word ELEPHANT?",
         "opts": ["2", "3", "4", "5"], "ans": 1, "exp": "E-L-E-P-H-A-N-T → E, E, A = 3 vowels!"},
        {"q": "🖊️ Which sentence is correct?",
         "opts": ["she go to school", "She goes to school", "She go school", "she goes school"],
         "ans": 1, "exp": "'She goes to school.' — capital S and 'goes'! ✏️"},
        {"q": "📝 What does the word ENORMOUS mean?",
         "opts": ["Very small", "Very fast", "Very big", "Very loud"], "ans": 2,
         "exp": "ENORMOUS = extremely large! Like a dinosaur 🦕"},
    ]},
    "🔬 Science":  {"color": "#a29bfe", "bg": "#2d1b69", "questions": [
        {"q": "🌍 How many planets are in our Solar System?",
         "opts": ["7", "8", "9", "10"], "ans": 1, "exp": "8 planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune! 🪐"},
        {"q": "💧 Water boils at how many degrees Celsius?",
         "opts": ["50°C", "75°C", "90°C", "100°C"], "ans": 3, "exp": "Water boils at 100°C at sea level! 🫧"},
        {"q": "🌱 Which part of a plant makes food using sunlight?",
         "opts": ["Root", "Stem", "Leaf", "Flower"], "ans": 2, "exp": "Leaves do photosynthesis — they're solar panels! ☀️🌿"},
        {"q": "🦁 What do you call animals that only eat plants?",
         "opts": ["Carnivores", "Omnivores", "Herbivores", "Insectivores"], "ans": 2,
         "exp": "Herbivores eat plants — like rabbits and deer! 🐰🌿"},
        {"q": "🌈 What are the three primary colours of light?",
         "opts": ["Red, Yellow, Blue", "Red, Green, Blue", "Cyan, Magenta, Yellow", "Orange, Green, Purple"],
         "ans": 1, "exp": "RGB — Red, Green, Blue make all colours of light! 💡"},
    ]},
    "🎨 Art":      {"color": "#fd79a8", "bg": "#6d2547", "questions": [
        {"q": "🎨 What colour do you get when you mix RED + YELLOW?",
         "opts": ["Purple", "Green", "Orange", "Brown"], "ans": 2, "exp": "Red + Yellow = Orange 🟠 — like a sunset!"},
        {"q": "🖼️ How many sides does a HEXAGON have?",
         "opts": ["5", "6", "7", "8"], "ans": 1, "exp": "HEXAgon = 6 sides, like a honeycomb! 🍯"},
        {"q": "🌈 Which colour is NOT in the rainbow?",
         "opts": ["Violet", "Pink", "Indigo", "Orange"], "ans": 1,
         "exp": "ROYGBIV: Red Orange Yellow Green Blue Indigo Violet — no Pink! 🌈"},
        {"q": "🎭 What colour do RED + BLUE make?",
         "opts": ["Green", "Orange", "Brown", "Purple"], "ans": 3, "exp": "Red + Blue = Purple 🟣 — royal colour!"},
        {"q": "✏️ Which shape has NO corners or edges?",
         "opts": ["Square", "Triangle", "Circle", "Rectangle"], "ans": 2,
         "exp": "A Circle is perfectly round — no corners! ⭕"},
    ]},
    "🌍 Geography": {"color": "#fdcb6e", "bg": "#6b4c00", "questions": [
        {"q": "🗺️ What is the largest continent?",
         "opts": ["Africa", "Europe", "Asia", "America"], "ans": 2,
         "exp": "Asia is the largest continent — over 44 million km²! 🌏"},
        {"q": "🌊 What is the longest river in the world?",
         "opts": ["Amazon", "Nile", "Yangtze", "Mississippi"], "ans": 1,
         "exp": "The Nile River in Africa is ~6,650 km long! 🐊"},
        {"q": "🏔️ What is the tallest mountain on Earth?",
         "opts": ["K2", "Mount Kilimanjaro", "Mount Everest", "Mont Blanc"], "ans": 2,
         "exp": "Mount Everest is 8,849 m — the roof of the world! ⛰️"},
        {"q": "🇦🇺 What is the capital of Australia?",
         "opts": ["Sydney", "Melbourne", "Canberra", "Perth"], "ans": 2,
         "exp": "Canberra is the capital — many people think it's Sydney! 🦘"},
        {"q": "🌐 How many oceans are there?",
         "opts": ["3", "4", "5", "6"], "ans": 2,
         "exp": "5 oceans: Pacific, Atlantic, Indian, Arctic, Southern! 🌊"},
    ]},
    "🦕 Animals":  {"color": "#e17055", "bg": "#5d2517", "questions": [
        {"q": "🦒 What is the tallest land animal?",
         "opts": ["Elephant", "Giraffe", "Horse", "Camel"], "ans": 1,
         "exp": "Giraffes can reach 5.5 m tall! Their necks alone are 1.8 m! 🦒"},
        {"q": "🦅 Which bird cannot fly?",
         "opts": ["Eagle", "Parrot", "Penguin", "Sparrow"], "ans": 2,
         "exp": "Penguins can't fly but are amazing swimmers! 🐧"},
        {"q": "🐘 How many teeth does an adult elephant have?",
         "opts": ["4", "8", "12", "26"], "ans": 0,
         "exp": "Elephants have just 4 molars at a time — but grow 6 sets in a lifetime! 🦷"},
        {"q": "🕷️ How many legs does a spider have?",
         "opts": ["6", "8", "10", "12"], "ans": 1,
         "exp": "Spiders are arachnids — 8 legs! Insects have 6. 🕸️"},
        {"q": "🐋 What is the largest animal on Earth?",
         "opts": ["Great White Shark", "African Elephant", "Blue Whale", "Giraffe"], "ans": 2,
         "exp": "The Blue Whale can be 30 m long and weigh 200 tonnes! 🐋"},
    ]},
}

AVATARS = ["🦁", "🐸", "🦊", "🐧", "🦋", "🐯", "🦄", "🐻"]

SAVE_FILE = os.path.join(os.path.dirname(__file__), "kids_progress.json")

def load_progress():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"xp": 0, "streak": 0, "avatar": 0, "stars": {}}

def save_progress(data):
    with open(SAVE_FILE, "w") as f:
        json.dump(data, f)

# ── helper widgets ───────────────────────────────────────────────────────────
class RoundButton(tk.Canvas):
    def __init__(self, parent, text, command, bg, fg="#ffffff",
                 width=220, height=52, radius=26, font_size=13, **kw):
        super().__init__(parent, width=width, height=height,
                         bg=parent["bg"], highlightthickness=0, **kw)
        self._bg = bg
        self._hover = self._lighten(bg)
        self._cmd = command
        self._r = radius
        self._w, self._h = width, height
        self._text = text
        self._fg = fg
        self._fs = font_size
        self._draw(self._bg)
        self.bind("<Enter>",    lambda e: self._draw(self._hover))
        self.bind("<Leave>",    lambda e: self._draw(self._bg))
        self.bind("<Button-1>", lambda e: command())

    def _lighten(self, hex_col):
        r = min(255, int(hex_col[1:3], 16) + 30)
        g = min(255, int(hex_col[3:5], 16) + 30)
        b = min(255, int(hex_col[5:7], 16) + 30)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _draw(self, color):
        self.delete("all")
        r, w, h = self._r, self._w, self._h
        self.create_arc(0, 0, 2*r, 2*r, start=90, extent=90, fill=color, outline=color)
        self.create_arc(w-2*r, 0, w, 2*r, start=0, extent=90, fill=color, outline=color)
        self.create_arc(0, h-2*r, 2*r, h, start=180, extent=90, fill=color, outline=color)
        self.create_arc(w-2*r, h-2*r, w, h, start=270, extent=90, fill=color, outline=color)
        self.create_rectangle(r, 0, w-r, h, fill=color, outline=color)
        self.create_rectangle(0, r, w, h-r, fill=color, outline=color)
        self.create_text(w//2, h//2, text=self._text, fill=self._fg,
                         font=("Helvetica", self._fs, "bold"))

# ── main application ─────────────────────────────────────────────────────────
class KidsLearningApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🌟 Kids Learning Adventure 🌟")
        self.geometry("900x680")
        self.resizable(True, True)
        self.configure(bg=COLORS["bg"])
        self.progress = load_progress()
        self._current_subject = None
        self._q_index = 0
        self._score = 0
        self._answered = False
        self._answer_buttons = []
        self._frames = {}
        self._build_all()
        self._show("home")

    # ── frame registry ───────────────────────────────────────────────────────
    def _build_all(self):
        for name, builder in [
            ("home",    self._build_home),
            ("lesson",  self._build_lesson),
            ("results", self._build_results),
        ]:
            f = tk.Frame(self, bg=COLORS["bg"])
            f.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._frames[name] = f
            builder(f)

    def _show(self, name):
        self._frames[name].lift()

    # ── HOME ─────────────────────────────────────────────────────────────────
    def _build_home(self, f):
        # top bar
        top = tk.Frame(f, bg=COLORS["accent2"], pady=10)
        top.pack(fill="x")

        self._avatar_lbl = tk.Label(top, text=AVATARS[self.progress["avatar"]],
                                    font=("Helvetica", 36), bg=COLORS["accent2"])
        self._avatar_lbl.pack(side="left", padx=20)

        tk.Label(top, text="Kids Learning Adventure",
                 font=("Helvetica", 22, "bold"), fg=COLORS["yellow"],
                 bg=COLORS["accent2"]).pack(side="left", padx=10)

        info = tk.Frame(top, bg=COLORS["accent2"])
        info.pack(side="right", padx=20)
        self._xp_lbl    = tk.Label(info, text=f"⭐ {self.progress['xp']} XP",
                                   font=("Helvetica", 14, "bold"), fg=COLORS["yellow"],
                                   bg=COLORS["accent2"])
        self._xp_lbl.pack()
        self._streak_lbl = tk.Label(info, text=f"🔥 {self.progress['streak']} day streak",
                                    font=("Helvetica", 12), fg=COLORS["orange"],
                                    bg=COLORS["accent2"])
        self._streak_lbl.pack()

        # avatar picker
        pick = tk.Frame(f, bg=COLORS["bg"], pady=6)
        pick.pack()
        tk.Label(pick, text="Pick your explorer:", font=("Helvetica", 11),
                 fg=COLORS["light"], bg=COLORS["bg"]).pack(side="left", padx=6)
        for i, av in enumerate(AVATARS):
            b = tk.Button(pick, text=av, font=("Helvetica", 22),
                          bg=COLORS["card"], fg=COLORS["white"],
                          relief="flat", cursor="hand2",
                          command=lambda idx=i: self._pick_avatar(idx))
            b.pack(side="left", padx=2)

        # subject grid
        tk.Label(f, text="Choose a Subject!", font=("Helvetica", 18, "bold"),
                 fg=COLORS["white"], bg=COLORS["bg"]).pack(pady=(10, 4))

        grid = tk.Frame(f, bg=COLORS["bg"])
        grid.pack(padx=30, pady=4, fill="both", expand=True)
        grid.columnconfigure((0, 1, 2), weight=1, uniform="col")

        for idx, (subj, info) in enumerate(SUBJECTS.items()):
            row, col = divmod(idx, 3)
            self._subject_card(grid, subj, info, row, col)

    def _subject_card(self, parent, subj, info, row, col):
        stars = self.progress["stars"].get(subj, 0)
        star_txt = "★" * stars + "☆" * (3 - stars)

        card = tk.Frame(parent, bg=info["bg"], padx=12, pady=12,
                        relief="flat", bd=0)
        card.grid(row=row, column=col, padx=8, pady=8, sticky="nsew")

        icon, name = subj.split(" ", 1)
        tk.Label(card, text=icon, font=("Helvetica", 46), bg=info["bg"]).pack()
        tk.Label(card, text=name, font=("Helvetica", 14, "bold"),
                 fg=info["color"], bg=info["bg"]).pack()
        tk.Label(card, text=star_txt, font=("Helvetica", 16),
                 fg=COLORS["yellow"], bg=info["bg"]).pack(pady=2)

        btn = tk.Button(card, text="▶  Start Lesson",
                        font=("Helvetica", 11, "bold"),
                        bg=info["color"], fg=COLORS["bg"], relief="flat",
                        cursor="hand2", padx=10, pady=4,
                        command=lambda s=subj: self._start_lesson(s))
        btn.pack(pady=4)

    def _pick_avatar(self, idx):
        self.progress["avatar"] = idx
        self._avatar_lbl.config(text=AVATARS[idx])
        save_progress(self.progress)

    # ── LESSON ───────────────────────────────────────────────────────────────
    def _build_lesson(self, f):
        # header
        hdr = tk.Frame(f, bg=COLORS["accent2"], pady=8)
        hdr.pack(fill="x")

        self._lesson_title = tk.Label(hdr, text="", font=("Helvetica", 18, "bold"),
                                      fg=COLORS["yellow"], bg=COLORS["accent2"])
        self._lesson_title.pack(side="left", padx=20)

        self._q_counter = tk.Label(hdr, text="", font=("Helvetica", 13),
                                   fg=COLORS["light"], bg=COLORS["accent2"])
        self._q_counter.pack(side="right", padx=20)

        # progress bar
        self._prog_var = tk.DoubleVar(value=0)
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Green.Horizontal.TProgressbar", troughcolor=COLORS["card"],
                        background=COLORS["green"], thickness=14)
        self._prog_bar = ttk.Progressbar(f, variable=self._prog_var, maximum=5,
                                          style="Green.Horizontal.TProgressbar")
        self._prog_bar.pack(fill="x", padx=20, pady=6)

        # question area
        q_frame = tk.Frame(f, bg=COLORS["card"], pady=20, padx=20)
        q_frame.pack(fill="x", padx=20, pady=8)

        self._q_emoji = tk.Label(q_frame, text="", font=("Helvetica", 52),
                                  bg=COLORS["card"])
        self._q_emoji.pack()

        self._q_text = tk.Label(q_frame, text="", font=("Helvetica", 15, "bold"),
                                 fg=COLORS["white"], bg=COLORS["card"],
                                 wraplength=820, justify="center")
        self._q_text.pack(pady=6)

        # answer buttons
        self._ans_frame = tk.Frame(f, bg=COLORS["bg"])
        self._ans_frame.pack(pady=10)

        self._feedback_lbl = tk.Label(f, text="", font=("Helvetica", 13),
                                       fg=COLORS["yellow"], bg=COLORS["bg"],
                                       wraplength=860, justify="center")
        self._feedback_lbl.pack(pady=4)

        self._next_btn = tk.Button(f, text="Next Question ➡",
                                    font=("Helvetica", 13, "bold"),
                                    bg=COLORS["accent1"], fg=COLORS["white"],
                                    relief="flat", cursor="hand2", padx=16, pady=8,
                                    command=self._next_question)
        # hidden until answered
        self._home_btn_lesson = tk.Button(f, text="🏠 Home",
                                           font=("Helvetica", 11),
                                           bg=COLORS["gray"], fg=COLORS["white"],
                                           relief="flat", cursor="hand2", padx=10, pady=6,
                                           command=self._go_home)
        self._home_btn_lesson.pack(side="bottom", pady=6)

    def _start_lesson(self, subject):
        self._current_subject = subject
        self._q_index = 0
        self._score = 0
        self._answered = False
        self._lesson_title.config(text=subject, fg=SUBJECTS[subject]["color"])
        self._show("lesson")
        self._load_question()

    def _load_question(self):
        self._answered = False
        self._feedback_lbl.config(text="")
        self._next_btn.pack_forget()

        qs = SUBJECTS[self._current_subject]["questions"]
        q  = qs[self._q_index]

        self._q_counter.config(text=f"Question {self._q_index + 1} / {len(qs)}")
        self._prog_var.set(self._q_index)

        # extract emoji from question text (first emoji cluster)
        parts = q["q"].split(" ", 1)
        self._q_emoji.config(text=parts[0] if len(parts[0]) <= 4 else "❓")
        self._q_text.config(text=q["q"])

        # rebuild answer buttons
        for w in self._ans_frame.winfo_children():
            w.destroy()
        self._answer_buttons = []

        colors_cycle = [COLORS["accent1"], COLORS["blue"], COLORS["purple"], COLORS["orange"]]
        for i, opt in enumerate(q["opts"]):
            btn = tk.Button(
                self._ans_frame,
                text=f"  {opt}  ",
                font=("Helvetica", 13, "bold"),
                bg=colors_cycle[i % 4],
                fg=COLORS["white"],
                relief="flat", cursor="hand2",
                padx=18, pady=10,
                command=lambda idx=i: self._check_answer(idx)
            )
            btn.grid(row=i // 2, column=i % 2, padx=10, pady=6, sticky="ew")
            self._answer_buttons.append(btn)

    def _check_answer(self, chosen):
        if self._answered:
            return
        self._answered = True

        qs  = SUBJECTS[self._current_subject]["questions"]
        q   = qs[self._q_index]
        correct = q["ans"]

        for i, btn in enumerate(self._answer_buttons):
            if i == correct:
                btn.config(bg=COLORS["green"])
            elif i == chosen:
                btn.config(bg=COLORS["accent1"])
            else:
                btn.config(bg=COLORS["gray"], state="disabled")
            btn.config(state="disabled")

        if chosen == correct:
            self._score += 1
            self._feedback_lbl.config(
                text=f"✅ Correct!  {q['exp']}", fg=COLORS["green"])
        else:
            self._feedback_lbl.config(
                text=f"❌ Not quite!  {q['exp']}", fg=COLORS["orange"])

        self._next_btn.pack(pady=6)

    def _next_question(self):
        self._q_index += 1
        qs = SUBJECTS[self._current_subject]["questions"]
        if self._q_index < len(qs):
            self._load_question()
        else:
            self._show_results()

    # ── RESULTS ──────────────────────────────────────────────────────────────
    def _build_results(self, f):
        self._res_avatar   = tk.Label(f, text="", font=("Helvetica", 64), bg=COLORS["bg"])
        self._res_avatar.pack(pady=(30, 0))

        self._res_title = tk.Label(f, text="", font=("Helvetica", 28, "bold"),
                                    fg=COLORS["yellow"], bg=COLORS["bg"])
        self._res_title.pack()

        self._res_score = tk.Label(f, text="", font=("Helvetica", 20),
                                    fg=COLORS["white"], bg=COLORS["bg"])
        self._res_score.pack(pady=4)

        self._res_stars = tk.Label(f, text="", font=("Helvetica", 36),
                                    fg=COLORS["yellow"], bg=COLORS["bg"])
        self._res_stars.pack()

        self._res_trophy = tk.Label(f, text="", font=("Helvetica", 52), bg=COLORS["bg"])
        self._res_trophy.pack(pady=4)

        self._res_xp = tk.Label(f, text="", font=("Helvetica", 16),
                                 fg=COLORS["green"], bg=COLORS["bg"])
        self._res_xp.pack()

        self._res_exp = tk.Label(f, text="", font=("Helvetica", 13),
                                  fg=COLORS["light"], bg=COLORS["bg"],
                                  wraplength=760, justify="center")
        self._res_exp.pack(pady=8)

        btn_row = tk.Frame(f, bg=COLORS["bg"])
        btn_row.pack(pady=16)

        tk.Button(btn_row, text="🔁  Play Again",
                  font=("Helvetica", 13, "bold"), bg=COLORS["accent3"],
                  fg=COLORS["white"], relief="flat", cursor="hand2",
                  padx=16, pady=10,
                  command=self._replay).pack(side="left", padx=12)

        tk.Button(btn_row, text="🏠  Home",
                  font=("Helvetica", 13, "bold"), bg=COLORS["accent2"],
                  fg=COLORS["white"], relief="flat", cursor="hand2",
                  padx=16, pady=10,
                  command=self._go_home).pack(side="left", padx=12)

    def _show_results(self):
        total = len(SUBJECTS[self._current_subject]["questions"])
        pct   = self._score / total

        stars = 1 if pct < 0.5 else (2 if pct < 0.9 else 3)
        xp    = self._score * 10 + (stars * 5)

        self.progress["xp"] += xp
        old_stars = self.progress["stars"].get(self._current_subject, 0)
        self.progress["stars"][self._current_subject] = max(old_stars, stars)
        self.progress["streak"] += 1
        save_progress(self.progress)

        trophy = "🏆" if stars == 3 else ("🥈" if stars == 2 else "🥉")
        star_txt = "★" * stars + "☆" * (3 - stars)

        msgs = {
            3: ("Perfect Score! Amazing!", "You got everything right — you're a superstar! 🌟"),
            2: ("Well Done!", "Great effort! A little more practice and you'll nail it! 💪"),
            1: ("Keep Going!", "Every mistake is a chance to learn. Try again! 🔄"),
        }
        title, note = msgs[stars]

        self._res_avatar.config(text=AVATARS[self.progress["avatar"]])
        self._res_title.config(text=title)
        self._res_score.config(text=f"{self._score} / {total} correct")
        self._res_stars.config(text=star_txt)
        self._res_trophy.config(text=trophy)
        self._res_xp.config(text=f"+{xp} XP  (Total: {self.progress['xp']} XP)")
        self._res_exp.config(text=note)

        self._xp_lbl.config(text=f"⭐ {self.progress['xp']} XP")
        self._streak_lbl.config(text=f"🔥 {self.progress['streak']} day streak")

        self._show("results")

    def _replay(self):
        self._start_lesson(self._current_subject)

    def _go_home(self):
        # refresh subject cards
        for w in self._frames["home"].winfo_children():
            w.destroy()
        self._build_home(self._frames["home"])
        self._show("home")


# ── entry point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = KidsLearningApp()
    app.mainloop()
