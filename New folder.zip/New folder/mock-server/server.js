/*
 * Mock ESP32 WebSocket server.
 * Lets you test the app's real WebSocket path without hardware.
 *
 *   npm install
 *   npm run mock-server
 *
 * Then set the app's WebSocket URL (Settings) to:  ws://localhost:81
 */
import { WebSocketServer } from 'ws'

const PORT = 81
const wss = new WebSocketServer({ port: PORT })

const devices = [
  { id: 'esp_ac_1', name: 'Bedroom AC', type: 'ac', state: { power: false, temperature: 22 } },
  { id: 'esp_light_1', name: 'Bedroom Light', type: 'light', state: { power: false, brightness: 80 } },
  { id: 'esp_fan_1', name: 'Ceiling Fan', type: 'fan', state: { power: false, fanSpeed: 2 } },
  { id: 'esp_tv_1', name: 'Living Room TV', type: 'tv', state: { power: false, volume: 20 } },
]

function readPower(d) {
  if (!d.state.power) return 0
  const base = { ac: 950, fan: 55, light: 10, tv: 100 }[d.type] || 40
  return Math.round((base + (Math.random() - 0.5) * base * 0.1) * 10) / 10
}
function readTemp() {
  return Math.round((24 + (Math.random() - 0.5) * 4) * 10) / 10
}

wss.on('connection', (ws) => {
  console.log('Client connected')
  ws.send(JSON.stringify({ type: 'hello', devices }))

  ws.on('message', (raw) => {
    let msg
    try {
      msg = JSON.parse(raw.toString())
    } catch {
      return
    }
    if (msg.type === 'sync') {
      ws.send(JSON.stringify({ type: 'hello', devices }))
    } else if (msg.type === 'command') {
      const d = devices.find((x) => x.id === msg.deviceId)
      if (d) {
        Object.assign(d.state, msg.patch)
        broadcast({ type: 'state', deviceId: d.id, state: msg.patch })
      }
    }
  })
})

function broadcast(obj) {
  const data = JSON.stringify(obj)
  wss.clients.forEach((c) => c.readyState === 1 && c.send(data))
}

setInterval(() => {
  devices.forEach((d) => {
    broadcast({
      type: 'telemetry',
      deviceId: d.id,
      power: readPower(d),
      temperature: readTemp(),
      ts: Date.now(),
    })
  })
}, 2000)

console.log(`Mock ESP32 WebSocket server running at ws://localhost:${PORT}`)
