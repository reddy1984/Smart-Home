import { useMemo } from 'react'
import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { useApp } from '../context/AppContext.jsx'
import DeviceCard from '../components/DeviceCard.jsx'
import Icon from '../components/Icon.jsx'

function Stat({ icon, label, value, unit, sub }) {
  return (
    <div className="card stat">
      <span className="label">
        <span className="stat-ico">
          <Icon name={icon} size={18} />
        </span>
        {label}
      </span>
      <span className="value">
        {value}
        {unit && <small> {unit}</small>}
      </span>
      {sub && (
        <span className="label" style={{ textTransform: 'none', letterSpacing: 0 }}>
          {sub}
        </span>
      )}
    </div>
  )
}

export default function Dashboard() {
  const { devices, getAllTelemetry, telemetryVersion, settings } = useApp()
  void telemetryVersion // re-render on each telemetry tick

  const tel = getAllTelemetry()

  // Aggregate the latest sample per device for the "now" numbers.
  const now = useMemo(() => {
    let totalPower = 0
    let tempSum = 0
    let tempCount = 0
    devices.forEach((d) => {
      const buf = tel[d.id]
      const last = buf && buf[buf.length - 1]
      if (last) {
        totalPower += last.power || 0
        if (last.temperature != null && d.type === 'ac') {
          tempSum += last.temperature
          tempCount++
        }
      }
    })
    return {
      totalPower,
      avgTemp: tempCount ? tempSum / tempCount : null,
      onCount: devices.filter((d) => d.state.power).length,
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [devices, telemetryVersion])

  // Build a combined time series (total power across all devices) for the chart.
  const series = useMemo(() => {
    // Use the device with the most samples as the time base.
    const buffers = Object.values(tel)
    if (!buffers.length) return []
    const maxLen = Math.max(...buffers.map((b) => b.length))
    const points = []
    for (let i = 0; i < maxLen; i++) {
      let power = 0
      let ts = null
      let tempSum = 0
      let tempCount = 0
      buffers.forEach((b) => {
        const offset = b.length - maxLen + i
        const sample = offset >= 0 ? b[offset] : null
        if (sample) {
          power += sample.power || 0
          ts = sample.ts
          if (sample.temperature != null) {
            tempSum += sample.temperature
            tempCount++
          }
        }
      })
      if (ts) {
        const d = new Date(ts)
        points.push({
          time: `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(
            2,
            '0'
          )}:${String(d.getSeconds()).padStart(2, '0')}`,
          power: Math.round(power),
          temp: tempCount ? Math.round((tempSum / tempCount) * 10) / 10 : null,
        })
      }
    }
    return points.slice(-60) // show last ~2 minutes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [telemetryVersion])

  // Rough cost estimate: assume the current draw runs for an hour.
  const kwhNow = now.totalPower / 1000
  const costPerHour = kwhNow * (settings.ratePerKwh || 0)

  return (
    <div>
      <div className="grid stats">
        <Stat
          icon="bolt"
          label="Live Power Draw"
          value={now.totalPower.toFixed(0)}
          unit="W"
          sub={`${(kwhNow).toFixed(2)} kW`}
        />
        <Stat
          icon="thermometer"
          label="Avg AC Temp"
          value={now.avgTemp != null ? now.avgTemp.toFixed(1) : '—'}
          unit={now.avgTemp != null ? '°C' : ''}
        />
        <Stat icon="plug" label="Active Devices" value={now.onCount} sub={`of ${devices.length} total`} />
        <Stat
          icon="wallet"
          label="Est. Cost / hour"
          value={`${settings.currency}${costPerHour.toFixed(2)}`}
          sub={`@ ${settings.currency}${settings.ratePerKwh}/kWh`}
        />
      </div>

      <div className="section-title">
        <h2>Real-time Power Consumption</h2>
      </div>
      <div className="card">
        <div style={{ width: '100%', height: 260 }}>
          <ResponsiveContainer>
            <AreaChart data={series} margin={{ top: 10, right: 10, left: -12, bottom: 0 }}>
              <defs>
                <linearGradient id="pwr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.6} />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#263256" strokeDasharray="3 3" />
              <XAxis dataKey="time" stroke="#93a0bd" fontSize={11} minTickGap={40} />
              <YAxis stroke="#93a0bd" fontSize={11} unit="W" />
              <Tooltip
                contentStyle={{
                  background: '#172037',
                  border: '1px solid #263256',
                  borderRadius: 10,
                  color: '#e8ecf6',
                }}
              />
              <Area
                type="monotone"
                dataKey="power"
                stroke="#3b82f6"
                strokeWidth={2}
                fill="url(#pwr)"
                isAnimationActive={false}
                name="Power (W)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="section-title">
        <h2>Temperature Monitor</h2>
      </div>
      <div className="card">
        <div style={{ width: '100%', height: 220 }}>
          <ResponsiveContainer>
            <LineChart data={series} margin={{ top: 10, right: 10, left: -12, bottom: 0 }}>
              <CartesianGrid stroke="#263256" strokeDasharray="3 3" />
              <XAxis dataKey="time" stroke="#93a0bd" fontSize={11} minTickGap={40} />
              <YAxis stroke="#93a0bd" fontSize={11} unit="°" domain={['dataMin - 1', 'dataMax + 1']} />
              <Tooltip
                contentStyle={{
                  background: '#172037',
                  border: '1px solid #263256',
                  borderRadius: 10,
                  color: '#e8ecf6',
                }}
              />
              <Line
                type="monotone"
                dataKey="temp"
                stroke="#22d3ee"
                strokeWidth={2}
                dot={false}
                isAnimationActive={false}
                name="Temp (°C)"
                connectNulls
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="section-title">
        <h2>Quick Controls</h2>
      </div>
      {devices.length ? (
        <div className="grid cards">
          {devices.map((d) => (
            <DeviceCard key={d.id} device={d} />
          ))}
        </div>
      ) : (
        <div className="empty card">
          <div className="big">🔌</div>
          No devices yet. Add one from the Devices tab.
        </div>
      )}
    </div>
  )
}
