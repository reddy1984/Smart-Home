import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import DeviceCard from '../components/DeviceCard.jsx'
import Modal from '../components/Modal.jsx'
import Icon from '../components/Icon.jsx'

const ICON_CHOICES = ['🛏️', '🛋️', '🍳', '🚿', '🚪', '🏠', '💼', '🎮', '🌳', '🚗']

function GroupForm({ group, onClose }) {
  const { addGroup, updateGroup, deleteGroup } = useApp()
  const editing = !!group
  const [name, setName] = useState(group?.name || '')
  const [icon, setIcon] = useState(group?.icon || '🏠')

  const submit = (e) => {
    e.preventDefault()
    if (!name.trim()) return
    if (editing) updateGroup(group.id, { name: name.trim(), icon })
    else addGroup({ name: name.trim(), icon })
    onClose()
  }

  return (
    <Modal title={editing ? 'Edit Room' : 'Add Room / Group'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="field">
          <label>Room name</label>
          <input
            className="input"
            autoFocus
            value={name}
            placeholder="e.g. Bedroom"
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="field">
          <label>Icon</label>
          <div className="chip-row">
            {ICON_CHOICES.map((c) => (
              <span
                key={c}
                className={`chip${icon === c ? ' active' : ''}`}
                style={{ fontSize: 18 }}
                onClick={() => setIcon(c)}
              >
                {c}
              </span>
            ))}
          </div>
        </div>
        <div className="modal-actions">
          {editing && (
            <button
              type="button"
              className="btn danger"
              style={{ marginRight: 'auto' }}
              onClick={() => {
                if (window.confirm(`Delete room "${group.name}"? Devices will become unassigned.`)) {
                  deleteGroup(group.id)
                  onClose()
                }
              }}
            >
              Delete
            </button>
          )}
          <button type="button" className="btn ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary">
            {editing ? 'Save' : 'Add Room'}
          </button>
        </div>
      </form>
    </Modal>
  )
}

export default function Groups() {
  const { groups, devices, setGroupPower } = useApp()
  const [form, setForm] = useState(null) // { group } or { new: true }

  const unassigned = devices.filter((d) => !d.groupId)

  return (
    <div>
      <div className="section-title" style={{ marginTop: 0 }}>
        <h2>Rooms & Groups</h2>
        <button className="btn primary" onClick={() => setForm({ new: true })}>
          <Icon name="plus" size={17} /> Add Room
        </button>
      </div>

      {groups.map((g) => {
        const inGroup = devices.filter((d) => d.groupId === g.id)
        const anyOn = inGroup.some((d) => d.state.power)
        return (
          <div key={g.id} style={{ marginBottom: 28 }}>
            <div className="list-item" style={{ marginBottom: 14 }}>
              <span style={{ fontSize: 26 }}>{g.icon}</span>
              <div className="grow">
                <div style={{ fontWeight: 600 }}>{g.name}</div>
                <div className="badge">{inGroup.length} device(s)</div>
              </div>
              <button className="btn sm" onClick={() => setGroupPower(g.id, true)}>
                <Icon name="power" size={14} style={{ color: 'var(--green)' }} /> All On
              </button>
              <button className="btn sm" onClick={() => setGroupPower(g.id, false)}>
                <Icon name="power" size={14} /> All Off
              </button>
              <button className="btn sm ghost" onClick={() => setForm({ group: g })}>
                Edit
              </button>
            </div>
            {inGroup.length ? (
              <div className="grid cards">
                {inGroup.map((d) => (
                  <DeviceCard key={d.id} device={d} />
                ))}
              </div>
            ) : (
              <div className="empty card" style={{ padding: 24 }}>
                No devices in {g.name} yet. Assign devices from the Devices tab.
              </div>
            )}
          </div>
        )
      })}

      {unassigned.length > 0 && (
        <div style={{ marginBottom: 28 }}>
          <div className="section-title">
            <h2>Unassigned</h2>
          </div>
          <div className="grid cards">
            {unassigned.map((d) => (
              <DeviceCard key={d.id} device={d} />
            ))}
          </div>
        </div>
      )}

      {form && <GroupForm group={form.group} onClose={() => setForm(null)} />}
    </div>
  )
}
