import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'

export default function Settings() {
  const { settings, updateSettings, connection, devices } = useApp()
  const [wsUrl, setWsUrl] = useState(settings.wsUrl)
  const [rate, setRate] = useState(settings.ratePerKwh)
  const [currency, setCurrency] = useState(settings.currency)
  const [saved, setSaved] = useState(false)

  const save = (e) => {
    e.preventDefault()
    updateSettings({ wsUrl: wsUrl.trim(), ratePerKwh: +rate || 0, currency: currency || '₹' })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div>
      <div className="section-title" style={{ marginTop: 0 }}>
        <h2>Settings</h2>
      </div>

      <div className="card" style={{ maxWidth: 640 }}>
        <form onSubmit={save}>
          <div className="field">
            <label>ESP32 WebSocket URL</label>
            <input
              className="input"
              value={wsUrl}
              placeholder="ws://192.168.1.50:81  (leave empty for Simulation Mode)"
              onChange={(e) => setWsUrl(e.target.value)}
            />
            <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>
              Point this at your ESP32's WebSocket server. Current status:{' '}
              <b style={{ color: 'var(--text)' }}>{connection}</b>. Leave blank to run in built-in
              Simulation Mode (no hardware needed).
            </span>
          </div>

          <div className="row" style={{ gap: 16 }}>
            <div className="field" style={{ flex: 1 }}>
              <label>Currency symbol</label>
              <input
                className="input"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
              />
            </div>
            <div className="field" style={{ flex: 2 }}>
              <label>Electricity rate (per kWh)</label>
              <input
                className="input"
                type="number"
                step="0.01"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
              />
            </div>
          </div>

          <div className="row">
            <button type="submit" className="btn primary">
              Save Settings
            </button>
            {saved && <span style={{ color: 'var(--green)', fontSize: 13 }}>✓ Saved</span>}
          </div>
        </form>
      </div>

      <div className="section-title">
        <h2>ESP32 Wiring Reference</h2>
      </div>
      <div className="card" style={{ maxWidth: 640 }}>
        <p style={{ marginTop: 0, color: 'var(--text-dim)', fontSize: 14 }}>
          GPIO pins assigned to your devices:
        </p>
        <div className="list">
          {devices.map((d) => (
            <div key={d.id} className="list-item" style={{ padding: '10px 14px' }}>
              <span className="grow">{d.name}</span>
              <span className="badge">{d.pin || 'unassigned'}</span>
            </div>
          ))}
        </div>
        <p style={{ color: 'var(--text-dim)', fontSize: 13, marginBottom: 0 }}>
          Flash the sketch in <code>firmware/esp32_firmware.ino</code> to your ESP32. It exposes a
          WebSocket server on port 81 speaking the JSON protocol this app uses.
        </p>
      </div>
    </div>
  )
}
