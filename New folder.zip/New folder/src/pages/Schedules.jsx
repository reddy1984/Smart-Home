import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import Modal from '../components/Modal.jsx'
import Toggle from '../components/Toggle.jsx'
import Icon from '../components/Icon.jsx'

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

function ScheduleForm({ schedule, onClose }) {
  const { addSchedule, updateSchedule, deleteSchedule, devices } = useApp()
  const editing = !!schedule

  const [name, setName] = useState(schedule?.name || '')
  const [time, setTime] = useState(schedule?.time || '07:00')
  const [days, setDays] = useState(schedule?.days || [1, 2, 3, 4, 5])
  const [deviceIds, setDeviceIds] = useState(schedule?.deviceIds || [])
  const [power, setPower] = useState(schedule?.action?.power ?? true)

  const toggleDay = (d) =>
    setDays((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d].sort()))
  const toggleDevice = (id) =>
    setDeviceIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))

  const submit = (e) => {
    e.preventDefault()
    if (!name.trim() || !deviceIds.length || !days.length) return
    const payload = {
      name: name.trim(),
      time,
      days,
      deviceIds,
      action: { power },
    }
    if (editing) updateSchedule(schedule.id, payload)
    else addSchedule(payload)
    onClose()
  }

  return (
    <Modal title={editing ? 'Edit Schedule' : 'New Schedule'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="field">
          <label>Name</label>
          <input
            className="input"
            autoFocus
            value={name}
            placeholder="e.g. Good Morning"
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div className="row" style={{ gap: 16 }}>
          <div className="field" style={{ flex: 1 }}>
            <label>Time</label>
            <input
              className="input"
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
            />
          </div>
          <div className="field" style={{ flex: 1 }}>
            <label>Action</label>
            <select
              className="input"
              value={power ? 'on' : 'off'}
              onChange={(e) => setPower(e.target.value === 'on')}
            >
              <option value="on">Turn On</option>
              <option value="off">Turn Off</option>
            </select>
          </div>
        </div>

        <div className="field">
          <label>Repeat on</label>
          <div className="chip-row">
            {DAY_LABELS.map((lbl, i) => (
              <span
                key={i}
                className={`chip${days.includes(i) ? ' active' : ''}`}
                onClick={() => toggleDay(i)}
              >
                {lbl}
              </span>
            ))}
          </div>
        </div>

        <div className="field">
          <label>Devices ({deviceIds.length} selected)</label>
          <div className="chip-row">
            {devices.map((d) => (
              <span
                key={d.id}
                className={`chip${deviceIds.includes(d.id) ? ' active' : ''}`}
                onClick={() => toggleDevice(d.id)}
              >
                {d.name}
              </span>
            ))}
          </div>
        </div>

        <div className="modal-actions">
          {editing && (
            <button
              type="button"
              className="btn danger"
              style={{ marginRight: 'auto' }}
              onClick={() => {
                deleteSchedule(schedule.id)
                onClose()
              }}
            >
              Delete
            </button>
          )}
          <button type="button" className="btn ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary">
            {editing ? 'Save' : 'Create'}
          </button>
        </div>
      </form>
    </Modal>
  )
}

export default function Schedules() {
  const { schedules, devices, updateSchedule } = useApp()
  const [form, setForm] = useState(null)

  const deviceName = (id) => devices.find((d) => d.id === id)?.name || 'Deleted device'
  const summarizeDays = (days) => {
    if (days.length === 7) return 'Every day'
    if (days.length === 5 && [1, 2, 3, 4, 5].every((d) => days.includes(d))) return 'Weekdays'
    if (days.length === 2 && days.includes(0) && days.includes(6)) return 'Weekends'
    return days.map((d) => DAY_LABELS[d]).join(', ')
  }

  return (
    <div>
      <div className="section-title" style={{ marginTop: 0 }}>
        <h2>Scheduling & Routines</h2>
        <button className="btn primary" onClick={() => setForm({ new: true })}>
          <Icon name="plus" size={17} /> New Schedule
        </button>
      </div>

      {schedules.length ? (
        <div className="list">
          {schedules.map((s) => (
            <div key={s.id} className="list-item">
              <div
                style={{
                  fontSize: 22,
                  width: 46,
                  textAlign: 'center',
                  opacity: s.enabled ? 1 : 0.4,
                }}
              >
                ⏰
              </div>
              <div className="grow">
                <div style={{ fontWeight: 600 }}>
                  {s.name}{' '}
                  <span className={`badge${s.action.power ? ' on' : ''}`}>
                    {s.action.power ? 'Turn On' : 'Turn Off'}
                  </span>
                </div>
                <div className="sub" style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 4 }}>
                  <b style={{ color: 'var(--text)' }}>{s.time}</b> · {summarizeDays(s.days)} ·{' '}
                  {s.deviceIds.map(deviceName).join(', ')}
                </div>
              </div>
              <Toggle
                checked={s.enabled}
                onChange={(v) => updateSchedule(s.id, { enabled: v })}
              />
              <button className="btn sm ghost" onClick={() => setForm({ schedule: s })}>
                Edit
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty card">
          <div className="big">⏰</div>
          No schedules yet. Automate your devices by time and day.
        </div>
      )}

      {form && <ScheduleForm schedule={form.schedule} onClose={() => setForm(null)} />}
    </div>
  )
}
