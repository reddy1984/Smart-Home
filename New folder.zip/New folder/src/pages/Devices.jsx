import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import DeviceCard from '../components/DeviceCard.jsx'
import DeviceForm from '../components/DeviceForm.jsx'
import Icon from '../components/Icon.jsx'

export default function Devices() {
  const { devices } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)

  const openNew = () => {
    setEditing(null)
    setShowForm(true)
  }
  const openEdit = (device) => {
    setEditing(device)
    setShowForm(true)
  }

  return (
    <div>
      <div className="section-title" style={{ marginTop: 0 }}>
        <h2>All Devices ({devices.length})</h2>
        <button className="btn primary" onClick={openNew}>
          <Icon name="plus" size={17} /> Add Device
        </button>
      </div>

      {devices.length ? (
        <div className="grid cards">
          {devices.map((d) => (
            <DeviceCard key={d.id} device={d} onEdit={openEdit} />
          ))}
        </div>
      ) : (
        <div className="empty card">
          <div className="big">🔌</div>
          No devices yet.
          <div style={{ marginTop: 14 }}>
            <button className="btn primary" onClick={openNew}>
              <Icon name="plus" size={17} /> Add your first device
            </button>
          </div>
        </div>
      )}

      {showForm && <DeviceForm device={editing} onClose={() => setShowForm(false)} />}
    </div>
  )
}
