import { useApp, DEVICE_TYPES } from '../context/AppContext.jsx'
import Toggle from './Toggle.jsx'
import Icon from './Icon.jsx'

/** Type-specific controls shown when the device is on. */
function DeviceControls({ device, control }) {
  const s = device.state
  switch (device.type) {
    case 'ac':
      return (
        <>
          <div className="control-row">
            <span>Temperature</span>
            <div className="row" style={{ gap: 8 }}>
              <input
                type="range"
                min="16"
                max="30"
                value={s.temperature}
                onChange={(e) => control({ temperature: +e.target.value })}
              />
              <b style={{ color: 'var(--text)', minWidth: 34 }}>{s.temperature}°C</b>
            </div>
          </div>
          <div className="control-row">
            <span>Mode</span>
            <select
              className="input"
              style={{ width: 130 }}
              value={s.mode}
              onChange={(e) => control({ mode: e.target.value })}
            >
              <option value="cool">Cool</option>
              <option value="heat">Heat</option>
              <option value="fan">Fan</option>
              <option value="dry">Dry</option>
              <option value="auto">Auto</option>
            </select>
          </div>
          <div className="control-row">
            <span>Fan speed</span>
            <div className="chip-row">
              {[1, 2, 3].map((n) => (
                <span
                  key={n}
                  className={`chip${s.fanSpeed === n ? ' active' : ''}`}
                  onClick={() => control({ fanSpeed: n })}
                >
                  {['Low', 'Med', 'High'][n - 1]}
                </span>
              ))}
            </div>
          </div>
        </>
      )
    case 'light':
      return (
        <>
          <div className="control-row">
            <span>Brightness</span>
            <div className="row" style={{ gap: 8 }}>
              <input
                type="range"
                min="1"
                max="100"
                value={s.brightness}
                onChange={(e) => control({ brightness: +e.target.value })}
              />
              <b style={{ color: 'var(--text)', minWidth: 34 }}>{s.brightness}%</b>
            </div>
          </div>
          <div className="control-row">
            <span>Color</span>
            <input
              type="color"
              value={s.color}
              onChange={(e) => control({ color: e.target.value })}
              style={{ width: 46, height: 30, border: 'none', background: 'none' }}
            />
          </div>
        </>
      )
    case 'fan':
      return (
        <>
          <div className="control-row">
            <span>Speed</span>
            <div className="chip-row">
              {[1, 2, 3, 4, 5].map((n) => (
                <span
                  key={n}
                  className={`chip${s.fanSpeed === n ? ' active' : ''}`}
                  onClick={() => control({ fanSpeed: n })}
                >
                  {n}
                </span>
              ))}
            </div>
          </div>
          <div className="control-row">
            <span>Oscillate</span>
            <Toggle checked={s.oscillate} onChange={(v) => control({ oscillate: v })} />
          </div>
        </>
      )
    case 'tv':
      return (
        <>
          <div className="control-row">
            <span>Volume</span>
            <div className="row" style={{ gap: 8 }}>
              <input
                type="range"
                min="0"
                max="100"
                value={s.volume}
                onChange={(e) => control({ volume: +e.target.value })}
              />
              <b style={{ color: 'var(--text)', minWidth: 34 }}>{s.volume}</b>
            </div>
          </div>
          <div className="control-row">
            <span>Source</span>
            <select
              className="input"
              style={{ width: 130 }}
              value={s.source}
              onChange={(e) => control({ source: e.target.value })}
            >
              <option>HDMI 1</option>
              <option>HDMI 2</option>
              <option>TV</option>
              <option>Netflix</option>
              <option>YouTube</option>
            </select>
          </div>
        </>
      )
    default:
      return null
  }
}

export default function DeviceCard({ device, onEdit }) {
  const { controlDevice, getTelemetry, telemetryVersion, groups } = useApp()
  // telemetryVersion is read so the card re-renders on every telemetry tick.
  void telemetryVersion

  const meta = DEVICE_TYPES[device.type]
  const buf = getTelemetry(device.id)
  const latest = buf[buf.length - 1]
  const group = groups.find((g) => g.id === device.groupId)
  const on = !!device.state.power

  const control = (patch) => controlDevice(device.id, patch)

  return (
    <div className={`card device-card${on ? ' on' : ''}`}>
      <div className="top">
        <div className="device-icon">{meta?.icon || '🔌'}</div>
        <div className="device-meta">
          <div className="name">{device.name}</div>
          <div className="sub">
            {meta?.label} {group ? `· ${group.name}` : ''}
          </div>
        </div>
        <Toggle checked={on} onChange={(v) => control({ power: v })} />
      </div>

      {on && (
        <div className="controls">
          <DeviceControls device={device} control={control} />
        </div>
      )}

      <div className="device-live">
        <span className="row" style={{ gap: 6 }}>
          <Icon name="bolt" size={14} style={{ color: 'var(--amber)' }} />
          <b>{latest ? latest.power.toFixed(0) : '0'}</b> W
        </span>
        {latest?.temperature != null && (
          <span className="row" style={{ gap: 6 }}>
            <Icon name="thermometer" size={14} style={{ color: 'var(--cyan)' }} />
            <b>{latest.temperature.toFixed(1)}</b> °C
          </span>
        )}
        <span style={{ marginLeft: 'auto' }}>
          {onEdit && (
            <button className="btn sm ghost" onClick={() => onEdit(device)}>
              <Icon name="edit" size={14} /> Edit
            </button>
          )}
        </span>
      </div>
    </div>
  )
}
