import { useState } from 'react'
import { useApp, DEVICE_TYPES } from '../context/AppContext.jsx'
import Modal from './Modal.jsx'

export default function DeviceForm({ device, onClose }) {
  const { addDevice, updateDevice, deleteDevice, groups } = useApp()
  const editing = !!device

  const [name, setName] = useState(device?.name || '')
  const [type, setType] = useState(device?.type || 'light')
  const [groupId, setGroupId] = useState(device?.groupId || '')
  const [pin, setPin] = useState(device?.pin || '')
  const [error, setError] = useState('')

  const submit = (e) => {
    e.preventDefault()
    if (!name.trim()) {
      setError('Please enter a device name.')
      return
    }
    const payload = { name: name.trim(), type, groupId: groupId || null, pin: pin.trim() }
    if (editing) {
      updateDevice(device.id, payload)
    } else {
      addDevice(payload)
    }
    onClose()
  }

  const remove = () => {
    if (window.confirm(`Delete "${device.name}"? This cannot be undone.`)) {
      deleteDevice(device.id)
      onClose()
    }
  }

  return (
    <Modal title={editing ? 'Edit Device' : 'Add New Device'} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="field">
          <label>Device name</label>
          <input
            className="input"
            value={name}
            autoFocus
            placeholder="e.g. Bedroom AC"
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div className="field">
          <label>Appliance type</label>
          <div className="chip-row">
            {Object.entries(DEVICE_TYPES).map(([key, m]) => (
              <span
                key={key}
                className={`chip${type === key ? ' active' : ''}`}
                onClick={() => setType(key)}
              >
                {m.icon} {m.label}
              </span>
            ))}
          </div>
        </div>

        <div className="field">
          <label>Room / Group</label>
          <select className="input" value={groupId} onChange={(e) => setGroupId(e.target.value)}>
            <option value="">Unassigned</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.icon} {g.name}
              </option>
            ))}
          </select>
        </div>

        <div className="field">
          <label>ESP32 GPIO pin / channel (optional)</label>
          <input
            className="input"
            value={pin}
            placeholder="e.g. GPIO 26"
            onChange={(e) => setPin(e.target.value)}
          />
        </div>

        {error && <div style={{ color: 'var(--red)', fontSize: 13, marginBottom: 10 }}>{error}</div>}

        <div className="modal-actions">
          {editing && (
            <button type="button" className="btn danger" onClick={remove} style={{ marginRight: 'auto' }}>
              Delete
            </button>
          )}
          <button type="button" className="btn ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary">
            {editing ? 'Save Changes' : 'Add Device'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
