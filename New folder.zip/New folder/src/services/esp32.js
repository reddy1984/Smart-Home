/**
 * ESP32 real-time communication layer.
 *
 * Talks to the ESP32 over a WebSocket. The ESP32 (or the bundled mock-server)
 * is expected to speak a small JSON protocol:
 *
 *   App  -> ESP32 : { type: "command", deviceId, patch: { power, ...state } }
 *   App  -> ESP32 : { type: "sync" }                      // request full state
 *   ESP32 -> App  : { type: "state",     deviceId, state }        // one device changed
 *   ESP32 -> App  : { type: "telemetry", deviceId, power, temperature, ts }
 *   ESP32 -> App  : { type: "hello",      devices: [...] }        // full snapshot
 *
 * If no WebSocket URL is configured (or the connection drops), the service
 * falls back to a local SIMULATOR so the whole UI stays fully functional for
 * demos and development without any hardware.
 */

const listeners = new Set()
let socket = null
let reconnectTimer = null
let simulator = null
let status = 'disconnected' // 'connected' | 'connecting' | 'disconnected' | 'simulated'
let currentUrl = ''

// devices getter/setter are injected by the context so the simulator can read
// live device definitions (which devices exist, their type, on/off state).
let getDevices = () => []

function emit(event) {
  listeners.forEach((fn) => {
    try {
      fn(event)
    } catch (e) {
      console.error('esp32 listener error', e)
    }
  })
}

function setStatus(next) {
  if (status === next) return
  status = next
  emit({ type: 'status', status })
}

export const esp32 = {
  get status() {
    return status
  },

  /** Register the function the service uses to read current device definitions. */
  bindDeviceSource(fn) {
    getDevices = fn
  },

  subscribe(fn) {
    listeners.add(fn)
    return () => listeners.delete(fn)
  },

  /** Connect to a real ESP32 WebSocket, or fall back to the simulator. */
  connect(url) {
    currentUrl = (url || '').trim()
    this.stopSimulator()
    clearTimeout(reconnectTimer)

    if (socket) {
      try {
        socket.onclose = null
        socket.close()
      } catch {}
      socket = null
    }

    if (!currentUrl) {
      this.startSimulator()
      return
    }

    setStatus('connecting')
    try {
      socket = new WebSocket(currentUrl)
    } catch (e) {
      console.warn('WebSocket create failed, using simulator', e)
      this.startSimulator()
      return
    }

    socket.onopen = () => {
      setStatus('connected')
      this.send({ type: 'sync' })
    }

    socket.onmessage = (evt) => {
      let msg
      try {
        msg = JSON.parse(evt.data)
      } catch {
        return
      }
      emit({ type: 'message', message: msg })
    }

    socket.onerror = () => {
      // onclose will handle the fallback
    }

    socket.onclose = () => {
      socket = null
      // Retry the real device a few times, then run the simulator so the UI
      // never appears "dead".
      setStatus('connecting')
      clearTimeout(reconnectTimer)
      reconnectTimer = setTimeout(() => {
        if (currentUrl) this.connect(currentUrl)
        else this.startSimulator()
      }, 3000)
      // Kick the simulator immediately so telemetry keeps flowing while retrying.
      this.startSimulator(true)
    }
  },

  /** Send a command to the ESP32 (or route it to the simulator). */
  send(payload) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(payload))
      return true
    }
    if (simulator) {
      simulator.handleCommand(payload)
      return true
    }
    return false
  },

  setDeviceState(deviceId, patch) {
    return this.send({ type: 'command', deviceId, patch })
  },

  disconnect() {
    clearTimeout(reconnectTimer)
    this.stopSimulator()
    if (socket) {
      try {
        socket.onclose = null
        socket.close()
      } catch {}
      socket = null
    }
    setStatus('disconnected')
  },

  // ----- Simulator (no hardware required) --------------------------------

  startSimulator(keepStatusConnecting = false) {
    if (simulator) return
    if (!keepStatusConnecting) setStatus('simulated')

    const state = {} // deviceId -> { power watts, temperature }

    const tick = () => {
      const devices = getDevices()
      devices.forEach((d) => {
        const on = d.state?.power
        const prev = state[d.id] || { power: 0, temperature: 24 }

        // Model realistic power draw per appliance type when ON.
        let target = 0
        if (on) {
          switch (d.type) {
            case 'ac':
              target = 900 + (d.state?.fanSpeed || 1) * 120
              break
            case 'fan':
              target = 25 + (d.state?.fanSpeed || 1) * 15
              break
            case 'light':
              target = (d.state?.brightness ?? 80) * 0.12
              break
            case 'tv':
              target = 90 + (d.state?.volume || 20) * 0.5
              break
            default:
              target = 40
          }
        }
        // Smooth toward target with a little noise.
        const noise = (Math.random() - 0.5) * (target * 0.05)
        const power = Math.max(0, prev.power + (target - prev.power) * 0.35 + noise)

        // Temperature drifts: AC cools its room, others warm slightly.
        let temp = prev.temperature
        if (d.type === 'ac' && on) {
          const setTemp = d.state?.temperature ?? 22
          temp += (setTemp - temp) * 0.05
        } else {
          temp += (26 - temp) * 0.01 + (Math.random() - 0.5) * 0.1
        }

        state[d.id] = { power, temperature: temp }

        emit({
          type: 'message',
          message: {
            type: 'telemetry',
            deviceId: d.id,
            power: Math.round(power * 10) / 10,
            temperature: Math.round(temp * 10) / 10,
            ts: performance.now(),
          },
        })
      })
    }

    const interval = setInterval(tick, 2000)
    tick()

    simulator = {
      handleCommand(payload) {
        // Echo the state change straight back, like a real device would.
        if (payload.type === 'command') {
          emit({
            type: 'message',
            message: { type: 'state', deviceId: payload.deviceId, state: payload.patch },
          })
        }
      },
      stop() {
        clearInterval(interval)
      },
    }
  },

  stopSimulator() {
    if (simulator) {
      simulator.stop()
      simulator = null
    }
  },
}
