import { useState } from 'react'
import { NavLink, Route, Routes } from 'react-router-dom'
import { useApp } from './context/AppContext.jsx'
import Icon from './components/Icon.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Devices from './pages/Devices.jsx'
import Groups from './pages/Groups.jsx'
import Schedules from './pages/Schedules.jsx'
import Settings from './pages/Settings.jsx'

const NAV = [
  { to: '/', label: 'Dashboard', icon: 'dashboard', end: true },
  { to: '/devices', label: 'Devices', icon: 'plug' },
  { to: '/groups', label: 'Rooms', icon: 'door' },
  { to: '/schedules', label: 'Scheduling', icon: 'clock' },
  { to: '/settings', label: 'Settings', icon: 'settings' },
]

function ConnectionPill() {
  const { connection } = useApp()
  const labels = {
    connected: 'ESP32 Connected',
    simulated: 'Simulation Mode',
    connecting: 'Connecting…',
    disconnected: 'Offline',
  }
  return (
    <span className={`conn ${connection}`}>
      <span className="dot" />
      {labels[connection] || connection}
    </span>
  )
}

function Sidebar({ drawer, onNavigate }) {
  return (
    <aside className={`sidebar${drawer ? ' drawer' : ''}`}>
      <div className="brand">
        <span className="brand-logo">
          <Icon name="home" size={22} />
        </span>
        <span>
          ESP32 Home
          <br />
          <span className="brand-sub">Smart Control</span>
        </span>
      </div>
      {NAV.map((n) => (
        <NavLink
          key={n.to}
          to={n.to}
          end={n.end}
          className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
          onClick={onNavigate}
        >
          <span className="ico">
            <Icon name={n.icon} size={20} />
          </span>
          {n.label}
        </NavLink>
      ))}
      <div className="sidebar-foot">
        Real-time smart home control
        <br />
        for the ESP32 microcontroller.
      </div>
    </aside>
  )
}

export default function App() {
  const [drawerOpen, setDrawerOpen] = useState(false)

  return (
    <div className="app-shell">
      <Sidebar />

      {drawerOpen && (
        <>
          <div className="drawer-backdrop" onClick={() => setDrawerOpen(false)} />
          <Sidebar drawer onNavigate={() => setDrawerOpen(false)} />
        </>
      )}

      <div className="main">
        <header className="header">
          <button className="hamburger" onClick={() => setDrawerOpen(true)} aria-label="Menu">
            ☰
          </button>
          <h1>Smart Home</h1>
          <div className="spacer" />
          <ConnectionPill />
        </header>

        <main className="content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/devices" element={<Devices />} />
            <Route path="/groups" element={<Groups />} />
            <Route path="/schedules" element={<Schedules />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>

      {/* Bottom tab bar on mobile */}
      <nav className="mobile-nav">
        {NAV.map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.end}
            className={({ isActive }) => (isActive ? 'active' : '')}
          >
            <span className="ico">
              <Icon name={n.icon} size={21} />
            </span>
            {n.label}
          </NavLink>
        ))}
      </nav>
    </div>
  )
}
