# ESP32 Smart Home Control

A responsive React app to control and manage home appliances (**AC, Light, Fan, TV**) with an
**ESP32** device, featuring a real-time **power consumption** and **temperature** monitoring
dashboard, device creation/editing, scheduling & routines, and room-based device grouping.

Works out of the box in **Simulation Mode** (no hardware required) and connects to a real ESP32
over WebSocket when you provide its URL.

## Features

- 📊 **Real-time dashboard** — live power draw, temperature charts, active-device count, and an
  hourly cost estimate.
- 🔌 **Appliance controls** — type-aware controls for AC (temp/mode/fan), Light (brightness/color),
  Fan (speed/oscillate), and TV (volume/source).
- ➕ **Create & edit devices** from the UI, assign a GPIO pin and a room.
- 🚪 **Rooms / groups** (Bedroom, Living Room, …) with one-tap *All On / All Off*.
- ⏰ **Scheduling & routines** — turn devices on/off at a time, on chosen days of the week.
- 🔄 **Real-time data transfer** between app and ESP32 over WebSocket (auto-reconnect + simulation
  fallback).
- 📱 **Fully responsive** — adapts to phones, tablets, and desktops with a mobile bottom tab bar and
  off-canvas menu. State persists in `localStorage`.

## Getting started

```bash
npm install
npm run dev
```

Open the printed URL. On a phone, use the `Network:` URL Vite prints (same Wi-Fi) — the dev server
is exposed on the LAN.

By default the app runs in **Simulation Mode**. To connect a real device, go to **Settings** and set
the **ESP32 WebSocket URL** (e.g. `ws://192.168.1.50:81`).

## Connecting a real ESP32

1. Open `firmware/esp32_firmware.ino` in the Arduino IDE.
2. Install libraries: *arduinoWebSockets*, *ArduinoJson* (and *DHT* if using a temp sensor).
3. Set your Wi-Fi credentials and map each device to a relay/PWM GPIO.
4. Flash it. The serial monitor prints the WebSocket URL — paste it into the app's Settings.

## Test the WebSocket path without hardware

A Node mock server mimics the ESP32 protocol:

```bash
npm run mock-server        # serves ws://localhost:81
```

Set the app's WebSocket URL to `ws://localhost:81`.

## Protocol

```
App   -> ESP32 : { "type":"command", "deviceId":"...", "patch":{ "power":true, ... } }
App   -> ESP32 : { "type":"sync" }
ESP32 -> App   : { "type":"hello", "devices":[ ... ] }
ESP32 -> App   : { "type":"state", "deviceId":"...", "state":{ ... } }
ESP32 -> App   : { "type":"telemetry", "deviceId":"...", "power":W, "temperature":C, "ts":ms }
```

## Project structure

```
firmware/esp32_firmware.ino   ESP32 Arduino sketch (WebSocket server)
mock-server/server.js         Node mock of the ESP32 for local testing
src/
  services/esp32.js           WebSocket client + simulation engine
  context/AppContext.jsx      Global state, persistence, scheduler engine
  components/                 DeviceCard, DeviceForm, Modal, Toggle
  pages/                      Dashboard, Devices, Groups, Schedules, Settings
```
