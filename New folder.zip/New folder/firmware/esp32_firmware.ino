/*
 * ESP32 Smart Home firmware
 * -------------------------
 * Exposes a WebSocket server (port 81) that speaks the JSON protocol used by
 * the React app, plus reads a DHT22 (temperature) and an INA219/ACS712-style
 * current sensor (power). Adjust pins/sensors to your wiring.
 *
 * Libraries (install via Arduino Library Manager):
 *   - WebSockets by Markus Sattler   (arduinoWebSockets)
 *   - ArduinoJson by Benoit Blanchon
 *   - DHT sensor library by Adafruit  (optional, for temperature)
 *
 * Protocol:
 *   App  -> ESP32 : { "type":"command", "deviceId":"...", "patch":{ "power":true, ... } }
 *   App  -> ESP32 : { "type":"sync" }
 *   ESP32 -> App  : { "type":"hello", "devices":[ ... ] }
 *   ESP32 -> App  : { "type":"state", "deviceId":"...", "state":{...} }
 *   ESP32 -> App  : { "type":"telemetry", "deviceId":"...", "power":W, "temperature":C, "ts":ms }
 */

#include <WiFi.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>

// ---------- User config ----------
const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASS = "YOUR_PASSWORD";

// Map each logical device to a relay/PWM GPIO.
// The deviceId strings MUST match the device ids used in the app (or send a
// "hello" so the app can adopt these ids).
struct Device {
  const char* id;
  const char* name;
  const char* type;   // "ac" | "light" | "fan" | "tv"
  uint8_t pin;
  bool power;
};

Device devices[] = {
  { "esp_ac_1",    "Bedroom AC",     "ac",    26, false },
  { "esp_light_1", "Bedroom Light",  "light", 25, false },
  { "esp_fan_1",   "Ceiling Fan",    "fan",   27, false },
  { "esp_tv_1",    "Living Room TV", "tv",    32, false },
};
const int DEVICE_COUNT = sizeof(devices) / sizeof(devices[0]);

WebSocketsServer webSocket = WebSocketsServer(81);
unsigned long lastTelemetry = 0;

Device* findDevice(const char* id) {
  for (int i = 0; i < DEVICE_COUNT; i++)
    if (strcmp(devices[i].id, id) == 0) return &devices[i];
  return nullptr;
}

void applyState(Device* d, JsonObject patch) {
  if (patch.containsKey("power")) {
    d->power = patch["power"];
    digitalWrite(d->pin, d->power ? HIGH : LOW);
  }
  // brightness/temperature/fanSpeed etc. could drive PWM/IR here.
}

void sendHello(uint8_t num) {
  StaticJsonDocument<1024> doc;
  doc["type"] = "hello";
  JsonArray arr = doc.createNestedArray("devices");
  for (int i = 0; i < DEVICE_COUNT; i++) {
    JsonObject o = arr.createNestedObject();
    o["id"] = devices[i].id;
    o["name"] = devices[i].name;
    o["type"] = devices[i].type;
    JsonObject st = o.createNestedObject("state");
    st["power"] = devices[i].power;
  }
  String out;
  serializeJson(doc, out);
  webSocket.sendTXT(num, out);
}

// Replace with a real current sensor reading (INA219 / ACS712).
float readPower(Device* d) {
  if (!d->power) return 0;
  if (strcmp(d->type, "ac") == 0) return 950 + random(-40, 40);
  if (strcmp(d->type, "fan") == 0) return 55 + random(-5, 5);
  if (strcmp(d->type, "light") == 0) return 10 + random(-2, 2);
  if (strcmp(d->type, "tv") == 0) return 100 + random(-10, 10);
  return 40;
}

// Replace with a real DHT22 reading.
float readTemperature(Device* d) {
  return 24.0 + random(-20, 20) / 10.0;
}

void broadcastTelemetry() {
  for (int i = 0; i < DEVICE_COUNT; i++) {
    StaticJsonDocument<256> doc;
    doc["type"] = "telemetry";
    doc["deviceId"] = devices[i].id;
    doc["power"] = readPower(&devices[i]);
    doc["temperature"] = readTemperature(&devices[i]);
    doc["ts"] = millis();
    String out;
    serializeJson(doc, out);
    webSocket.broadcastTXT(out);
  }
}

void onWsEvent(uint8_t num, WStype_t type, uint8_t* payload, size_t length) {
  if (type == WStype_CONNECTED) {
    sendHello(num);
    return;
  }
  if (type != WStype_TEXT) return;

  StaticJsonDocument<512> doc;
  if (deserializeJson(doc, payload, length)) return;

  const char* msgType = doc["type"];
  if (!msgType) return;

  if (strcmp(msgType, "sync") == 0) {
    sendHello(num);
  } else if (strcmp(msgType, "command") == 0) {
    const char* id = doc["deviceId"];
    Device* d = findDevice(id);
    if (d) {
      applyState(d, doc["patch"].as<JsonObject>());
      // Echo the new state back to every client.
      StaticJsonDocument<256> resp;
      resp["type"] = "state";
      resp["deviceId"] = id;
      resp["state"] = doc["patch"];
      String out;
      serializeJson(resp, out);
      webSocket.broadcastTXT(out);
    }
  }
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < DEVICE_COUNT; i++) {
    pinMode(devices[i].pin, OUTPUT);
    digitalWrite(devices[i].pin, LOW);
  }

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(400);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("Connected. Use this WebSocket URL in the app: ws://");
  Serial.print(WiFi.localIP());
  Serial.println(":81");

  webSocket.begin();
  webSocket.onEvent(onWsEvent);
}

void loop() {
  webSocket.loop();
  if (millis() - lastTelemetry > 2000) {
    lastTelemetry = millis();
    broadcastTelemetry();
  }
}
