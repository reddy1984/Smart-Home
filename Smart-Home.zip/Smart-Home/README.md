# ESP32 Smart Home Control

A responsive React app to control and manage home appliances (**AC, Light, Fan, TV**) with an
**ESP32** device, featuring a real-time **power consumption** and **temperature** monitoring
dashboard, device creation/editing, scheduling & routines, and room-based device grouping.

Works out of the box in **Simulation Mode** (no hardware required) and connects to a real ESP32
over WebSocket when you provide its URL.

## Features

- 📊 **Real-time dashboard** — live power draw, temperature charts, active-device count, and an
  hourly cost estimate.
- 🔌 **Appliance controls** — type-aware controls for AC (temp/mode/fan), Light (brightness/color),
  Fan (speed/oscillate), and TV (volume/source).
- ➕ **Create & edit devices** from the UI, assign a GPIO pin and a room.
- 🚪 **Rooms / groups** (Bedroom, Living Room, …) with one-tap *All On / All Off*.
- ⏰ **Scheduling & routines** — turn devices on/off at a time, on chosen days of the week.
- 🔄 **Real-time data transfer** between app and ESP32 over WebSocket (auto-reconnect + simulation
  fallback).
- 🔐 **Secure key authentication** — HMAC-SHA256 challenge–response; the shared secret is never sent
  over the wire, and a fresh nonce per connection blocks replay attacks.
- 📱 **Fully responsive + installable as an Android APK** (via Capacitor). Mobile bottom tab bar and
  off-canvas menu; state persists in `localStorage`.

## Getting started

```bash
npm install
npm run dev
```

Open the printed URL. On a phone, use the `Network:` URL Vite prints (same Wi-Fi) — the dev server
is exposed on the LAN.

By default the app runs in **Simulation Mode**. To connect a real device, go to **Settings** and set
the **ESP32 WebSocket URL** (e.g. `ws://192.168.1.50:81`).

## Connecting a real ESP32

1. Open `firmware/esp32_firmware.ino` in the Arduino IDE.
2. Install libraries: *arduinoWebSockets*, *ArduinoJson* (and *DHT* if using a temp sensor).
3. Set your Wi-Fi credentials and map each device to a relay/PWM GPIO.
4. Flash it. The serial monitor prints the WebSocket URL — paste it into the app's Settings.

## Test the WebSocket path without hardware

A Node mock server mimics the ESP32 protocol:

```bash
npm run mock-server        # serves ws://localhost:81
```

Set the app's WebSocket URL to `ws://localhost:81`.

## Secure key

1. Open **Settings** in the app → **Generate strong key** → **Copy**.
2. Paste it into the firmware: `const char* AUTH_KEY = "<your key>";` and flash the ESP32.
3. Save settings in the app. Status shows **ESP32 Connected** once the handshake succeeds, or
   **Auth Failed — Bad Key** if the keys don't match.

Leave the key blank to disable authentication (open / simulation mode). To test the secured path
locally: `AUTH_KEY=yourkey npm run mock-server`.

## Build as an Android APK

The app is wrapped with **Capacitor**. Quick version:

```bash
npm install
npm run build
npm run cap:add        # once — creates the android/ project
npm run cap:open       # build + sync + open in Android Studio
```

Then in Android Studio: **Build ▸ Build APK(s)**. Full step-by-step (including CLI builds,
cleartext `ws://` config, signing, and app icon) is in **[ANDROID_BUILD.md](ANDROID_BUILD.md)**.

## Protocol

```
# Auth handshake (only when a key is set)
ESP32 -> App   : { "type":"challenge", "nonce":"<hex>" }
App   -> ESP32 : { "type":"auth", "hmac": HMAC_SHA256(key, nonce) }
ESP32 -> App   : { "type":"auth_ok" }   |   { "type":"auth_fail" }

# Control + telemetry (after auth)
App   -> ESP32 : { "type":"command", "deviceId":"...", "patch":{ "power":true, ... } }
App   -> ESP32 : { "type":"sync" }
ESP32 -> App   : { "type":"hello", "devices":[ ... ] }
ESP32 -> App   : { "type":"state", "deviceId":"...", "state":{ ... } }
ESP32 -> App   : { "type":"telemetry", "deviceId":"...", "power":W, "temperature":C, "ts":ms }
```

## Project structure

```
firmware/esp32_firmware.ino   ESP32 Arduino sketch (WebSocket server)
mock-server/server.js         Node mock of the ESP32 for local testing
src/
  services/esp32.js           WebSocket client + simulation engine
  context/AppContext.jsx      Global state, persistence, scheduler engine
  components/                 DeviceCard, DeviceForm, Modal, Toggle
  pages/                      Dashboard, Devices, Groups, Schedules, Settings
```
