# Building the Android APK

The app is wrapped with **Capacitor**, which packages the built React app into a
native Android project you can compile to an `.apk`.

## Prerequisites (one-time)

1. **Node.js 18+** — https://nodejs.org
2. **Android Studio** (includes the Android SDK) — https://developer.android.com/studio
3. **JDK 17** — bundled with recent Android Studio (set `JAVA_HOME` if building from the CLI).

Open Android Studio once so it installs the SDK + build tools.

## First-time setup

From the project folder:

```bash
npm install            # installs React + Capacitor
npm run build          # produces dist/
npm run cap:add        # creates the native android/ project (run once)
npm run cap:sync       # copies the web build into android/
```

`npm run cap:add` runs `cap add android` and generates the `android/` folder.

## Build the APK

### Option A — Android Studio (easiest)

```bash
npm run cap:open       # builds, syncs, and opens the project in Android Studio
```

In Android Studio: **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
When it finishes, click **locate** — the debug APK is at:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

Copy that to your phone and install it (enable "Install unknown apps").

### Option B — command line (Windows)

```bash
npm run apk:debug
```

This builds the web app, syncs it, and runs `gradlew.bat assembleDebug`. The APK
lands in `android/app/build/outputs/apk/debug/app-debug.apk`.

> On macOS/Linux use `cd android && ./gradlew assembleDebug`.

## After you change the app

Any time you edit the React code, re-sync before rebuilding:

```bash
npm run cap:sync       # or npm run cap:open
```

## Connecting to the ESP32 from the phone

- Phone and ESP32 must be on the **same Wi-Fi**.
- In the app's **Settings**, set the WebSocket URL to your ESP32, e.g. `ws://192.168.1.50:81`,
  and paste the **secure key** (the same one flashed to the firmware's `AUTH_KEY`).
- The app is configured for **cleartext** traffic (`capacitor.config.json` →
  `server.cleartext: true`) so plain `ws://` to your local device works. For a device that
  supports TLS you can use `wss://` instead.

### (Optional) Restrict cleartext to your LAN only

If you prefer to allow cleartext only for private IP ranges instead of globally, after
`cap:add` create `android/app/src/main/res/xml/network_security_config.xml` with the contents of
[`android-config/network_security_config.xml`](android-config/network_security_config.xml) and
reference it in `android/app/src/main/AndroidManifest.xml`:

```xml
<application
    android:networkSecurityConfig="@xml/network_security_config"
    ... >
```

## Release / Play Store build

For a signed release APK/AAB:

```bash
cd android
gradlew.bat assembleRelease     # or bundleRelease for an .aab
```

You'll need to create a keystore and configure signing in `android/app/build.gradle`.
See https://capacitorjs.com/docs/android/deploying-to-google-play

## App icon & name

- Name is set in `capacitor.config.json` (`appName`).
- To change the launcher icon, use Android Studio's **Image Asset** tool
  (right-click `res` ▸ New ▸ Image Asset), or drop icons into `android/app/src/main/res/mipmap-*`.
