/**
 * Dependency-free HMAC-SHA256 (hex output).
 *
 * We can't rely on window.crypto.subtle because the app may run in an
 * "insecure context" (a phone hitting http://192.168.x.x:5173 over the LAN),
 * where SubtleCrypto is unavailable. This compact pure-JS implementation works
 * everywhere — browser, Capacitor WebView, and Node-like environments.
 */

function sha256(bytes) {
  const K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
    0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
    0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
    0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
    0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
    0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]
  let h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a
  let h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19

  const l = bytes.length
  const withOne = l + 1
  const k = (56 - (withOne % 64) + 64) % 64
  const total = withOne + k + 8
  const msg = new Uint8Array(total)
  msg.set(bytes)
  msg[l] = 0x80
  const bitLen = l * 8
  // 64-bit big-endian length (high 32 bits assumed 0 for our short inputs)
  msg[total - 4] = (bitLen >>> 24) & 0xff
  msg[total - 3] = (bitLen >>> 16) & 0xff
  msg[total - 2] = (bitLen >>> 8) & 0xff
  msg[total - 1] = bitLen & 0xff

  const w = new Int32Array(64)
  const rotr = (x, n) => (x >>> n) | (x << (32 - n))

  for (let i = 0; i < total; i += 64) {
    for (let j = 0; j < 16; j++) {
      w[j] =
        (msg[i + j * 4] << 24) |
        (msg[i + j * 4 + 1] << 16) |
        (msg[i + j * 4 + 2] << 8) |
        msg[i + j * 4 + 3]
    }
    for (let j = 16; j < 64; j++) {
      const s0 = rotr(w[j - 15], 7) ^ rotr(w[j - 15], 18) ^ (w[j - 15] >>> 3)
      const s1 = rotr(w[j - 2], 17) ^ rotr(w[j - 2], 19) ^ (w[j - 2] >>> 10)
      w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0
    }
    let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7
    for (let j = 0; j < 64; j++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
      const ch = (e & f) ^ (~e & g)
      const t1 = (h + S1 + ch + K[j] + w[j]) | 0
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
      const maj = (a & b) ^ (a & c) ^ (b & c)
      const t2 = (S0 + maj) | 0
      h = g; g = f; f = e; e = (d + t1) | 0
      d = c; c = b; b = a; a = (t1 + t2) | 0
    }
    h0 = (h0 + a) | 0; h1 = (h1 + b) | 0; h2 = (h2 + c) | 0; h3 = (h3 + d) | 0
    h4 = (h4 + e) | 0; h5 = (h5 + f) | 0; h6 = (h6 + g) | 0; h7 = (h7 + h) | 0
  }

  const out = new Uint8Array(32)
  ;[h0, h1, h2, h3, h4, h5, h6, h7].forEach((hv, i) => {
    out[i * 4] = (hv >>> 24) & 0xff
    out[i * 4 + 1] = (hv >>> 16) & 0xff
    out[i * 4 + 2] = (hv >>> 8) & 0xff
    out[i * 4 + 3] = hv & 0xff
  })
  return out
}

function toBytes(str) {
  return new TextEncoder().encode(str)
}
function toHex(bytes) {
  let s = ''
  for (let i = 0; i < bytes.length; i++) s += bytes[i].toString(16).padStart(2, '0')
  return s
}

/** HMAC-SHA256(key, message) -> lowercase hex string. */
export function hmacSha256Hex(key, message) {
  const blockSize = 64
  let keyBytes = toBytes(key)
  if (keyBytes.length > blockSize) keyBytes = sha256(keyBytes)

  const oKeyPad = new Uint8Array(blockSize)
  const iKeyPad = new Uint8Array(blockSize)
  for (let i = 0; i < blockSize; i++) {
    const b = i < keyBytes.length ? keyBytes[i] : 0
    oKeyPad[i] = b ^ 0x5c
    iKeyPad[i] = b ^ 0x36
  }

  const msgBytes = toBytes(message)
  const inner = new Uint8Array(iKeyPad.length + msgBytes.length)
  inner.set(iKeyPad)
  inner.set(msgBytes, iKeyPad.length)
  const innerHash = sha256(inner)

  const outer = new Uint8Array(oKeyPad.length + innerHash.length)
  outer.set(oKeyPad)
  outer.set(innerHash, oKeyPad.length)
  return toHex(sha256(outer))
}

/** Generate a cryptographically strong random hex key (default 32 bytes). */
export function generateKey(bytes = 32) {
  const buf = new Uint8Array(bytes)
  if (globalThis.crypto?.getRandomValues) {
    globalThis.crypto.getRandomValues(buf)
  } else {
    for (let i = 0; i < bytes; i++) buf[i] = Math.floor(Math.random() * 256)
  }
  return toHex(buf)
}
