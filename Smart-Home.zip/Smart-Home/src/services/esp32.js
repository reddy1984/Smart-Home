/**
 * ESP32 real-time communication layer with secure authentication.
 *
 * Auth uses an HMAC challenge–response so the shared secret key is NEVER sent
 * over the wire (important because ESP32 links are usually plaintext ws://):
 *
 *   ESP32 -> App : { type:"challenge", nonce:"<random hex>" }
 *   App   -> ESP32: { type:"auth", hmac: HMAC_SHA256(key, nonce) }
 *   ESP32 -> App : { type:"auth_ok" }        // hmac matched
 *   ESP32 -> App : { type:"auth_fail" }      // hmac mismatch -> connection refused
 *
 * A fresh random nonce per connection prevents replay attacks. Commands and
 * telemetry only flow after "auth_ok". If no key is configured, auth is skipped
 * (open mode / simulation).
 *
 * Control/telemetry protocol (post-auth):
 *   App  -> ESP32 : { type:"command", deviceId, patch:{ power, ... } }
 *   App  -> ESP32 : { type:"sync" }
 *   ESP32 -> App  : { type:"state",     deviceId, state }
 *   ESP32 -> App  : { type:"telemetry", deviceId, power, temperature, ts }
 *   ESP32 -> App  : { type:"hello",     devices:[...] }
 */

import { hmacSha256Hex } from './hmac.js'

const listeners = new Set()
let socket = null
let reconnectTimer = null
let simulator = null
let status = 'disconnected' // connected | connecting | disconnected | simulated | unauthorized
let currentUrl = ''
let authKey = ''
let authed = false
let outbox = [] // commands queued until the handshake completes

let getDevices = () => []

function emit(event) {
  listeners.forEach((fn) => {
    try {
      fn(event)
    } catch (e) {
      console.error('esp32 listener error', e)
    }
  })
}

function setStatus(next) {
  if (status === next) return
  status = next
  emit({ type: 'status', status })
}

function flushOutbox() {
  if (!(socket && socket.readyState === WebSocket.OPEN)) return
  outbox.forEach((p) => socket.send(JSON.stringify(p)))
  outbox = []
}

export const esp32 = {
  get status() {
    return status
  },

  bindDeviceSource(fn) {
    getDevices = fn
  },

  subscribe(fn) {
    listeners.add(fn)
    return () => listeners.delete(fn)
  },

  /**
   * Connect to a real ESP32 WebSocket, or fall back to the simulator.
   * @param {string} url  ws:// or wss:// URL (empty => simulator)
   * @param {string} key  shared secret; empty => no authentication
   */
  connect(url, key = '') {
    currentUrl = (url || '').trim()
    authKey = (key || '').trim()
    authed = false
    outbox = []
    this.stopSimulator()
    clearTimeout(reconnectTimer)

    if (socket) {
      try {
        socket.onclose = null
        socket.close()
      } catch {}
      socket = null
    }

    if (!currentUrl) {
      this.startSimulator()
      return
    }

    setStatus('connecting')
    try {
      socket = new WebSocket(currentUrl)
    } catch (e) {
      console.warn('WebSocket create failed, using simulator', e)
      this.startSimulator()
      return
    }

    socket.onopen = () => {
      if (authKey) {
        // Wait for the device's challenge; stay in "connecting" until auth_ok.
        setStatus('connecting')
      } else {
        authed = true
        setStatus('connected')
        this.send({ type: 'sync' })
      }
    }

    socket.onmessage = (evt) => {
      let msg
      try {
        msg = JSON.parse(evt.data)
      } catch {
        return
      }

      // ---- Auth handshake is handled internally, not forwarded ----
      if (msg.type === 'challenge') {
        const hmac = hmacSha256Hex(authKey, String(msg.nonce ?? ''))
        try {
          socket.send(JSON.stringify({ type: 'auth', hmac }))
        } catch {}
        return
      }
      if (msg.type === 'auth_ok') {
        authed = true
        setStatus('connected')
        this.send({ type: 'sync' })
        flushOutbox()
        return
      }
      if (msg.type === 'auth_fail') {
        setStatus('unauthorized')
        // Wrong key: stop retrying so we don't hammer the device.
        clearTimeout(reconnectTimer)
        try {
          socket.onclose = null
          socket.close()
        } catch {}
        socket = null
        return
      }

      emit({ type: 'message', message: msg })
    }

    socket.onerror = () => {}

    socket.onclose = () => {
      socket = null
      if (status === 'unauthorized') return // don't auto-reconnect on bad key
      setStatus('connecting')
      clearTimeout(reconnectTimer)
      reconnectTimer = setTimeout(() => {
        if (currentUrl) this.connect(currentUrl, authKey)
        else this.startSimulator()
      }, 3000)
      this.startSimulator(true) // keep telemetry flowing while retrying
    }
  },

  send(payload) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      const isAuthMsg = payload.type === 'auth'
      if (authed || !authKey || isAuthMsg) {
        socket.send(JSON.stringify(payload))
      } else {
        outbox.push(payload) // queue until auth_ok
      }
      return true
    }
    if (simulator) {
      simulator.handleCommand(payload)
      return true
    }
    return false
  },

  setDeviceState(deviceId, patch) {
    return this.send({ type: 'command', deviceId, patch })
  },

  disconnect() {
    clearTimeout(reconnectTimer)
    this.stopSimulator()
    if (socket) {
      try {
        socket.onclose = null
        socket.close()
      } catch {}
      socket = null
    }
    setStatus('disconnected')
  },

  // ----- Simulator (no hardware required) --------------------------------

  startSimulator(keepStatusConnecting = false) {
    if (simulator) return
    if (!keepStatusConnecting) setStatus('simulated')

    const state = {}

    const tick = () => {
      const devices = getDevices()
      devices.forEach((d) => {
        const on = d.state?.power
        const prev = state[d.id] || { power: 0, temperature: 24 }

        let target = 0
        if (on) {
          switch (d.type) {
            case 'ac':
              target = 900 + (d.state?.fanSpeed || 1) * 120
              break
            case 'fan':
              target = 25 + (d.state?.fanSpeed || 1) * 15
              break
            case 'light':
              target = (d.state?.brightness ?? 80) * 0.12
              break
            case 'tv':
              target = 90 + (d.state?.volume || 20) * 0.5
              break
            default:
              target = 40
          }
        }
        const noise = (Math.random() - 0.5) * (target * 0.05)
        const power = Math.max(0, prev.power + (target - prev.power) * 0.35 + noise)

        let temp = prev.temperature
        if (d.type === 'ac' && on) {
          const setTemp = d.state?.temperature ?? 22
          temp += (setTemp - temp) * 0.05
        } else {
          temp += (26 - temp) * 0.01 + (Math.random() - 0.5) * 0.1
        }

        state[d.id] = { power, temperature: temp }

        emit({
          type: 'message',
          message: {
            type: 'telemetry',
            deviceId: d.id,
            power: Math.round(power * 10) / 10,
            temperature: Math.round(temp * 10) / 10,
            ts: performance.now(),
          },
        })
      })
    }

    const interval = setInterval(tick, 2000)
    tick()

    simulator = {
      handleCommand(payload) {
        if (payload.type === 'command') {
          emit({
            type: 'message',
            message: { type: 'state', deviceId: payload.deviceId, state: payload.patch },
          })
        }
      },
      stop() {
        clearInterval(interval)
      },
    }
  },

  stopSimulator() {
    if (simulator) {
      simulator.stop()
      simulator = null
    }
  },
}
