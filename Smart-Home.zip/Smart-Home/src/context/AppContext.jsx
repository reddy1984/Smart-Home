import { createContext, useContext, useEffect, useMemo, useReducer, useRef, useState } from 'react'
import { esp32 } from '../services/esp32.js'

const AppContext = createContext(null)
export const useApp = () => useContext(AppContext)

const STORAGE_KEY = 'esp32-home-control-v1'

/** Per-type default control state used when creating a new device. */
export const DEVICE_TYPES = {
  ac: {
    label: 'Air Conditioner',
    icon: '❄️',
    defaults: { power: false, temperature: 22, mode: 'cool', fanSpeed: 2 },
  },
  light: {
    label: 'Light',
    icon: '💡',
    defaults: { power: false, brightness: 80, color: '#ffd18c' },
  },
  fan: {
    label: 'Fan',
    icon: '🌀',
    defaults: { power: false, fanSpeed: 2, oscillate: false },
  },
  tv: {
    label: 'TV',
    icon: '📺',
    defaults: { power: false, volume: 20, source: 'HDMI 1' },
  },
}

let idCounter = 0
const uid = (prefix = 'id') =>
  `${prefix}_${Date.now().toString(36)}_${(idCounter++).toString(36)}`

// ---- Seed data (used on first run) --------------------------------------

function seedState() {
  const groups = [
    { id: 'grp_bedroom', name: 'Bedroom', icon: '🛏️' },
    { id: 'grp_living', name: 'Living Room', icon: '🛋️' },
    { id: 'grp_kitchen', name: 'Kitchen', icon: '🍳' },
  ]
  const devices = [
    mkDevice({ name: 'Bedroom AC', type: 'ac', groupId: 'grp_bedroom', pin: 'GPIO 26' }),
    mkDevice({ name: 'Bedroom Light', type: 'light', groupId: 'grp_bedroom', pin: 'GPIO 25' }),
    mkDevice({ name: 'Ceiling Fan', type: 'fan', groupId: 'grp_bedroom', pin: 'GPIO 27' }),
    mkDevice({ name: 'Living Room TV', type: 'tv', groupId: 'grp_living', pin: 'GPIO 32' }),
    mkDevice({ name: 'Living Room Light', type: 'light', groupId: 'grp_living', pin: 'GPIO 33' }),
    mkDevice({ name: 'Kitchen Light', type: 'light', groupId: 'grp_kitchen', pin: 'GPIO 14' }),
  ]
  const schedules = [
    {
      id: uid('sch'),
      name: 'Good Morning',
      deviceIds: [devices[1].id, devices[5].id],
      action: { power: true },
      time: '06:30',
      days: [1, 2, 3, 4, 5],
      enabled: true,
      lastRun: null,
    },
    {
      id: uid('sch'),
      name: 'Bedtime AC',
      deviceIds: [devices[0].id],
      action: { power: true, temperature: 24 },
      time: '22:30',
      days: [0, 1, 2, 3, 4, 5, 6],
      enabled: true,
      lastRun: null,
    },
  ]
  return {
    devices,
    groups,
    schedules,
    settings: { wsUrl: '', authKey: '', currency: '₹', ratePerKwh: 8 },
  }
}

function mkDevice({ name, type, groupId, pin }) {
  return {
    id: uid('dev'),
    name,
    type,
    groupId: groupId || null,
    pin: pin || '',
    online: true,
    state: { ...DEVICE_TYPES[type].defaults },
  }
}

// ---- Reducer -------------------------------------------------------------

function reducer(state, action) {
  switch (action.type) {
    case 'LOAD':
      return action.payload

    case 'ADD_DEVICE':
      return { ...state, devices: [...state.devices, action.device] }

    case 'UPDATE_DEVICE':
      return {
        ...state,
        devices: state.devices.map((d) =>
          d.id === action.id ? { ...d, ...action.patch } : d
        ),
      }

    case 'DELETE_DEVICE':
      return { ...state, devices: state.devices.filter((d) => d.id !== action.id) }

    case 'SET_DEVICE_STATE':
      return {
        ...state,
        devices: state.devices.map((d) =>
          d.id === action.id ? { ...d, state: { ...d.state, ...action.patch } } : d
        ),
      }

    case 'SET_DEVICE_ONLINE':
      return {
        ...state,
        devices: state.devices.map((d) =>
          d.id === action.id ? { ...d, online: action.online } : d
        ),
      }

    case 'ADD_GROUP':
      return { ...state, groups: [...state.groups, action.group] }

    case 'UPDATE_GROUP':
      return {
        ...state,
        groups: state.groups.map((g) =>
          g.id === action.id ? { ...g, ...action.patch } : g
        ),
      }

    case 'DELETE_GROUP':
      return {
        ...state,
        groups: state.groups.filter((g) => g.id !== action.id),
        devices: state.devices.map((d) =>
          d.groupId === action.id ? { ...d, groupId: null } : d
        ),
      }

    case 'ADD_SCHEDULE':
      return { ...state, schedules: [...state.schedules, action.schedule] }

    case 'UPDATE_SCHEDULE':
      return {
        ...state,
        schedules: state.schedules.map((s) =>
          s.id === action.id ? { ...s, ...action.patch } : s
        ),
      }

    case 'DELETE_SCHEDULE':
      return { ...state, schedules: state.schedules.filter((s) => s.id !== action.id) }

    case 'UPDATE_SETTINGS':
      return { ...state, settings: { ...state.settings, ...action.patch } }

    default:
      return state
  }
}

function init() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch {}
  return seedState()
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, init)
  const [connection, setConnection] = useState(esp32.status)

  // Live telemetry ring buffers, kept in a ref (updated ~every 2s) plus a
  // small versioned mirror in state so charts re-render.
  const telemetryRef = useRef({}) // deviceId -> [{ ts, power, temperature }]
  const [telemetryVersion, setTelemetryVersion] = useState(0)

  const stateRef = useRef(state)
  stateRef.current = state

  // Persist everything to localStorage.
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {}
  }, [state])

  // Wire up the ESP32 service once.
  useEffect(() => {
    esp32.bindDeviceSource(() => stateRef.current.devices)

    const unsub = esp32.subscribe((event) => {
      if (event.type === 'status') {
        setConnection(event.status)
        return
      }
      if (event.type !== 'message') return
      const msg = event.message

      if (msg.type === 'telemetry') {
        const buf = telemetryRef.current[msg.deviceId] || []
        buf.push({
          ts: Date.now(),
          power: msg.power ?? 0,
          temperature: msg.temperature ?? null,
        })
        // Keep ~15 minutes at a 2s cadence.
        if (buf.length > 450) buf.shift()
        telemetryRef.current[msg.deviceId] = buf
        setTelemetryVersion((v) => (v + 1) % 1_000_000)
      } else if (msg.type === 'state') {
        dispatch({ type: 'SET_DEVICE_STATE', id: msg.deviceId, patch: msg.state })
      } else if (msg.type === 'hello' && Array.isArray(msg.devices)) {
        msg.devices.forEach((d) => {
          dispatch({ type: 'SET_DEVICE_ONLINE', id: d.id, online: true })
          if (d.state) dispatch({ type: 'SET_DEVICE_STATE', id: d.id, patch: d.state })
        })
      }
    })

    esp32.connect(stateRef.current.settings.wsUrl, stateRef.current.settings.authKey)
    return unsub
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Reconnect when the WebSocket URL or the secure key changes.
  const wsUrl = state.settings.wsUrl
  const authKey = state.settings.authKey
  useEffect(() => {
    esp32.connect(wsUrl, authKey)
  }, [wsUrl, authKey])

  // ---- Scheduler engine: fires schedules at their time on matching days. --
  useEffect(() => {
    const check = () => {
      const now = new Date()
      const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(
        now.getMinutes()
      ).padStart(2, '0')}`
      const day = now.getDay()
      const stamp = now.toDateString() + ' ' + hhmm

      stateRef.current.schedules.forEach((s) => {
        if (!s.enabled) return
        if (s.time !== hhmm) return
        if (!s.days.includes(day)) return
        if (s.lastRun === stamp) return // avoid double-firing within the same minute

        s.deviceIds.forEach((id) => {
          dispatch({ type: 'SET_DEVICE_STATE', id, patch: s.action })
          esp32.setDeviceState(id, s.action)
        })
        dispatch({ type: 'UPDATE_SCHEDULE', id: s.id, patch: { lastRun: stamp } })
      })
    }
    const t = setInterval(check, 15_000)
    check()
    return () => clearInterval(t)
  }, [])

  // ---- Action helpers -----------------------------------------------------

  const api = useMemo(
    () => ({
      // Devices
      addDevice(input) {
        const device = mkDevice(input)
        // allow caller to override the generated defaults
        if (input.state) device.state = { ...device.state, ...input.state }
        dispatch({ type: 'ADD_DEVICE', device })
        return device
      },
      updateDevice(id, patch) {
        dispatch({ type: 'UPDATE_DEVICE', id, patch })
      },
      deleteDevice(id) {
        dispatch({ type: 'DELETE_DEVICE', id })
        delete telemetryRef.current[id]
      },
      /** Change a control (e.g. power/brightness) AND push it to the ESP32. */
      controlDevice(id, patch) {
        dispatch({ type: 'SET_DEVICE_STATE', id, patch })
        esp32.setDeviceState(id, patch)
      },

      // Groups
      addGroup(input) {
        const group = { id: uid('grp'), icon: '🏠', ...input }
        dispatch({ type: 'ADD_GROUP', group })
        return group
      },
      updateGroup(id, patch) {
        dispatch({ type: 'UPDATE_GROUP', id, patch })
      },
      deleteGroup(id) {
        dispatch({ type: 'DELETE_GROUP', id })
      },
      /** Turn every device in a group on/off at once. */
      setGroupPower(groupId, power) {
        stateRef.current.devices
          .filter((d) => d.groupId === groupId)
          .forEach((d) => api.controlDevice(d.id, { power }))
      },

      // Schedules
      addSchedule(input) {
        const schedule = {
          id: uid('sch'),
          enabled: true,
          days: [0, 1, 2, 3, 4, 5, 6],
          action: { power: true },
          deviceIds: [],
          lastRun: null,
          ...input,
        }
        dispatch({ type: 'ADD_SCHEDULE', schedule })
        return schedule
      },
      updateSchedule(id, patch) {
        dispatch({ type: 'UPDATE_SCHEDULE', id, patch })
      },
      deleteSchedule(id) {
        dispatch({ type: 'DELETE_SCHEDULE', id })
      },

      // Settings
      updateSettings(patch) {
        dispatch({ type: 'UPDATE_SETTINGS', patch })
      },

      // Telemetry access
      getTelemetry(deviceId) {
        return telemetryRef.current[deviceId] || []
      },
      getAllTelemetry() {
        return telemetryRef.current
      },
    }),
    []
  )

  const value = {
    ...state,
    connection,
    telemetryVersion,
    ...api,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
