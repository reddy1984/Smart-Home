/*
 * ESP32 Smart Home firmware (with secure HMAC authentication)
 * -----------------------------------------------------------
 * Exposes a WebSocket server (port 81) that speaks the JSON protocol used by
 * the React app, and secures it with an HMAC-SHA256 challenge–response so the
 * shared secret key is never transmitted.
 *
 * Libraries (install via Arduino Library Manager):
 *   - WebSockets by Markus Sattler   (arduinoWebSockets)
 *   - ArduinoJson by Benoit Blanchon
 *   (mbedTLS for HMAC ships with the ESP32 core — no extra install.)
 *
 * Auth flow:
 *   ESP32 -> App : { "type":"challenge", "nonce":"<hex>" }   (sent on connect)
 *   App   -> ESP32: { "type":"auth", "hmac":"<hex>" }
 *   ESP32 -> App : { "type":"auth_ok" }  or  { "type":"auth_fail" } + disconnect
 *
 * Set AUTH_KEY below to the SAME key you enter in the app's Settings page.
 * Leave AUTH_KEY = "" to disable authentication.
 */

#include <WiFi.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>
#include "mbedtls/md.h"
#include "esp_system.h"

// ---------- User config ----------
const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASS = "YOUR_PASSWORD";

// >>> Paste the SAME key you generate in the app's Settings page. <<<
const char* AUTH_KEY = "";  // e.g. "3f9a...". Empty = no authentication.

struct Device {
  const char* id;
  const char* name;
  const char* type;   // "ac" | "light" | "fan" | "tv"
  uint8_t pin;
  bool power;
};

Device devices[] = {
  { "esp_ac_1",    "Bedroom AC",     "ac",    26, false },
  { "esp_light_1", "Bedroom Light",  "light", 25, false },
  { "esp_fan_1",   "Ceiling Fan",    "fan",   27, false },
  { "esp_tv_1",    "Living Room TV", "tv",    32, false },
};
const int DEVICE_COUNT = sizeof(devices) / sizeof(devices[0]);

WebSocketsServer webSocket = WebSocketsServer(81);
unsigned long lastTelemetry = 0;

// Per-client auth state (WebSocketsServer supports a handful of clients).
#define MAX_CLIENTS 8
bool   clientAuthed[MAX_CLIENTS] = { false };
char   clientNonce[MAX_CLIENTS][33];

// ---------- HMAC-SHA256 (hex) ----------
String hmacSha256Hex(const char* key, const char* msg) {
  byte out[32];
  const mbedtls_md_info_t* info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
  mbedtls_md_context_t ctx;
  mbedtls_md_init(&ctx);
  mbedtls_md_setup(&ctx, info, 1);
  mbedtls_md_hmac_starts(&ctx, (const unsigned char*)key, strlen(key));
  mbedtls_md_hmac_update(&ctx, (const unsigned char*)msg, strlen(msg));
  mbedtls_md_hmac_finish(&ctx, out);
  mbedtls_md_free(&ctx);

  char hex[65];
  for (int i = 0; i < 32; i++) sprintf(hex + i * 2, "%02x", out[i]);
  hex[64] = 0;
  return String(hex);
}

void makeNonce(char* dst) {
  const char* h = "0123456789abcdef";
  for (int i = 0; i < 32; i++) dst[i] = h[esp_random() & 0x0f];
  dst[32] = 0;
}

bool authRequired() { return AUTH_KEY[0] != '\0'; }

Device* findDevice(const char* id) {
  for (int i = 0; i < DEVICE_COUNT; i++)
    if (strcmp(devices[i].id, id) == 0) return &devices[i];
  return nullptr;
}

void applyState(Device* d, JsonObject patch) {
  if (patch.containsKey("power")) {
    d->power = patch["power"];
    digitalWrite(d->pin, d->power ? HIGH : LOW);
  }
  // brightness / temperature / fanSpeed could drive PWM / IR here.
}

void sendHello(uint8_t num) {
  StaticJsonDocument<1024> doc;
  doc["type"] = "hello";
  JsonArray arr = doc.createNestedArray("devices");
  for (int i = 0; i < DEVICE_COUNT; i++) {
    JsonObject o = arr.createNestedObject();
    o["id"] = devices[i].id;
    o["name"] = devices[i].name;
    o["type"] = devices[i].type;
    JsonObject st = o.createNestedObject("state");
    st["power"] = devices[i].power;
  }
  String out;
  serializeJson(doc, out);
  webSocket.sendTXT(num, out);
}

float readPower(Device* d) {
  if (!d->power) return 0;
  if (strcmp(d->type, "ac") == 0) return 950 + random(-40, 40);
  if (strcmp(d->type, "fan") == 0) return 55 + random(-5, 5);
  if (strcmp(d->type, "light") == 0) return 10 + random(-2, 2);
  if (strcmp(d->type, "tv") == 0) return 100 + random(-10, 10);
  return 40;
}
float readTemperature(Device* d) { return 24.0 + random(-20, 20) / 10.0; }

void broadcastTelemetry() {
  for (int i = 0; i < DEVICE_COUNT; i++) {
    StaticJsonDocument<256> doc;
    doc["type"] = "telemetry";
    doc["deviceId"] = devices[i].id;
    doc["power"] = readPower(&devices[i]);
    doc["temperature"] = readTemperature(&devices[i]);
    doc["ts"] = millis();
    String out;
    serializeJson(doc, out);
    // Only send telemetry to authenticated clients.
    for (uint8_t c = 0; c < MAX_CLIENTS; c++) {
      if (!authRequired() || clientAuthed[c]) webSocket.sendTXT(c, out);
    }
  }
}

void onWsEvent(uint8_t num, WStype_t type, uint8_t* payload, size_t length) {
  if (num >= MAX_CLIENTS) return;

  if (type == WStype_DISCONNECTED) {
    clientAuthed[num] = false;
    return;
  }

  if (type == WStype_CONNECTED) {
    clientAuthed[num] = false;
    if (authRequired()) {
      makeNonce(clientNonce[num]);
      StaticJsonDocument<128> doc;
      doc["type"] = "challenge";
      doc["nonce"] = clientNonce[num];
      String out;
      serializeJson(doc, out);
      webSocket.sendTXT(num, out);
    } else {
      clientAuthed[num] = true;
      sendHello(num);
    }
    return;
  }

  if (type != WStype_TEXT) return;

  StaticJsonDocument<512> doc;
  if (deserializeJson(doc, payload, length)) return;
  const char* msgType = doc["type"];
  if (!msgType) return;

  // ---- Authentication ----
  if (strcmp(msgType, "auth") == 0) {
    const char* got = doc["hmac"] | "";
    String want = hmacSha256Hex(AUTH_KEY, clientNonce[num]);
    if (want.equalsIgnoreCase(got)) {
      clientAuthed[num] = true;
      webSocket.sendTXT(num, "{\"type\":\"auth_ok\"}");
      sendHello(num);
    } else {
      webSocket.sendTXT(num, "{\"type\":\"auth_fail\"}");
      webSocket.disconnect(num);
    }
    return;
  }

  // Reject everything else until authenticated.
  if (authRequired() && !clientAuthed[num]) return;

  if (strcmp(msgType, "sync") == 0) {
    sendHello(num);
  } else if (strcmp(msgType, "command") == 0) {
    const char* id = doc["deviceId"];
    Device* d = findDevice(id);
    if (d) {
      applyState(d, doc["patch"].as<JsonObject>());
      StaticJsonDocument<256> resp;
      resp["type"] = "state";
      resp["deviceId"] = id;
      resp["state"] = doc["patch"];
      String out;
      serializeJson(resp, out);
      // Echo only to authenticated clients.
      for (uint8_t c = 0; c < MAX_CLIENTS; c++) {
        if (!authRequired() || clientAuthed[c]) webSocket.sendTXT(c, out);
      }
    }
  }
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < DEVICE_COUNT; i++) {
    pinMode(devices[i].pin, OUTPUT);
    digitalWrite(devices[i].pin, LOW);
  }

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(400);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("Connected. WebSocket URL for the app: ws://");
  Serial.print(WiFi.localIP());
  Serial.println(":81");
  Serial.println(authRequired() ? "Authentication: ENABLED" : "Authentication: DISABLED");

  webSocket.begin();
  webSocket.onEvent(onWsEvent);
}

void loop() {
  webSocket.loop();
  if (millis() - lastTelemetry > 2000) {
    lastTelemetry = millis();
    broadcastTelemetry();
  }
}
