/*
 * Mock ESP32 WebSocket server (with HMAC authentication).
 * Test the app's real WebSocket + secure-key path without hardware.
 *
 *   npm install
 *   npm run mock-server           # open mode (no key)
 *   AUTH_KEY=yourkey npm run mock-server   # require the same key in the app
 *
 * Then set the app's WebSocket URL (Settings) to:  ws://localhost:81
 */
import { WebSocketServer } from 'ws'
import crypto from 'node:crypto'

const PORT = 81
const AUTH_KEY = process.env.AUTH_KEY || '' // empty => authentication disabled
const wss = new WebSocketServer({ port: PORT })

const devices = [
  { id: 'esp_ac_1', name: 'Bedroom AC', type: 'ac', state: { power: false, temperature: 22 } },
  { id: 'esp_light_1', name: 'Bedroom Light', type: 'light', state: { power: false, brightness: 80 } },
  { id: 'esp_fan_1', name: 'Ceiling Fan', type: 'fan', state: { power: false, fanSpeed: 2 } },
  { id: 'esp_tv_1', name: 'Living Room TV', type: 'tv', state: { power: false, volume: 20 } },
]

const hmac = (key, msg) => crypto.createHmac('sha256', key).update(msg).digest('hex')

function readPower(d) {
  if (!d.state.power) return 0
  const base = { ac: 950, fan: 55, light: 10, tv: 100 }[d.type] || 40
  return Math.round((base + (Math.random() - 0.5) * base * 0.1) * 10) / 10
}
const readTemp = () => Math.round((24 + (Math.random() - 0.5) * 4) * 10) / 10
const send = (ws, obj) => ws.readyState === 1 && ws.send(JSON.stringify(obj))

wss.on('connection', (ws) => {
  ws.authed = !AUTH_KEY
  ws.nonce = crypto.randomBytes(16).toString('hex')

  if (AUTH_KEY) {
    send(ws, { type: 'challenge', nonce: ws.nonce })
  } else {
    send(ws, { type: 'hello', devices })
  }

  ws.on('message', (raw) => {
    let msg
    try {
      msg = JSON.parse(raw.toString())
    } catch {
      return
    }

    if (msg.type === 'auth') {
      if (msg.hmac === hmac(AUTH_KEY, ws.nonce)) {
        ws.authed = true
        send(ws, { type: 'auth_ok' })
        send(ws, { type: 'hello', devices })
        console.log('Client authenticated ✔')
      } else {
        send(ws, { type: 'auth_fail' })
        console.log('Client auth FAILED - wrong key')
        ws.close()
      }
      return
    }

    if (AUTH_KEY && !ws.authed) return // ignore until authenticated

    if (msg.type === 'sync') {
      send(ws, { type: 'hello', devices })
    } else if (msg.type === 'command') {
      const d = devices.find((x) => x.id === msg.deviceId)
      if (d) {
        Object.assign(d.state, msg.patch)
        broadcast({ type: 'state', deviceId: d.id, state: msg.patch })
      }
    }
  })
})

function broadcast(obj) {
  const data = JSON.stringify(obj)
  wss.clients.forEach((c) => c.readyState === 1 && (!AUTH_KEY || c.authed) && c.send(data))
}

setInterval(() => {
  devices.forEach((d) => {
    broadcast({
      type: 'telemetry',
      deviceId: d.id,
      power: readPower(d),
      temperature: readTemp(),
      ts: Date.now(),
    })
  })
}, 2000)

console.log(`Mock ESP32 WebSocket server at ws://localhost:${PORT}`)
console.log(AUTH_KEY ? 'Authentication: ENABLED' : 'Authentication: DISABLED (set AUTH_KEY to enable)')
